TRUNCATE address_book; INSERT INTO address_book (`address_book_id`, `user_id`, `entry_gender`, `customers_id`, `entry_company`, `entry_firstname`, `entry_lastname`, `entry_street_address`, `entry_suburb`, `entry_postcode`, `entry_city`, `entry_state`, `entry_country_id`, `entry_zone_id`, `entry_latitude`, `entry_longitude`); VALUES ('1', '1', '', '', '', 'Shahzad', 'Ali', 'Shahrah-e-Usman, Sector 5c/4 Sector 5 C 4 North Karachi Twp', '', '75850', 'Karachi', '', '162', '0', '', '');


TRUNCATE alert_settings; INSERT INTO alert_settings (`alert_id`, `create_customer_email`, `create_customer_notification`, `order_status_email`, `order_status_notification`, `new_product_email`, `new_product_notification`, `forgot_email`, `forgot_notification`, `news_email`, `news_notification`, `contact_us_email`, `contact_us_notification`, `order_email`, `order_notification`); VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1');


TRUNCATE api_calls_list; TRUNCATE banners; TRUNCATE banners_history; TRUNCATE block_ips; TRUNCATE categories; INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('-1', '120', '120', '0', '0', '', '', 'uncategorized', '0', '', '2020-12-19 10:21:07');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('1', '124', '122', '0', '', '', '', 'groceries', '1', '2020-12-17 07:31:44', '2020-12-21 12:12:37');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('2', '125', '129', '1', '', '', '', 'cooking-oil', '1', '2020-12-17 07:35:17', '2020-12-21 12:13:04');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('4', '142', '142', '0', '', '', '', 'unilever', '1', '2020-12-18 09:35:16', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('5', '143', '143', '4', '', '', '', 'knorr', '1', '2020-12-18 09:36:17', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('6', '144', '144', '4', '', '', '', 'dove', '1', '2020-12-18 09:37:43', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('7', '147', '147', '4', '', '', '', 'lifebuoy', '1', '2020-12-18 02:18:15', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('8', '147', '147', '7', '', '', '', 'shampoo', '1', '2020-12-18 02:21:06', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('9', '148', '148', '0', '', '', '', 'tetra-pak', '1', '2020-12-21 09:34:53', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('10', '149', '149', '0', '', '', '', 'national-foods', '1', '2020-12-21 09:47:29', '');


INSERT INTO categories (`categories_id`, `categories_image`, `categories_icon`, `parent_id`, `sort_order`, `date_added`, `last_modified`, `categories_slug`, `categories_status`, `created_at`, `updated_at`); VALUES ('11', '150', '150', '0', '', '', '', 'pepsico', '1', '2020-12-21 09:52:11', '');


TRUNCATE categories_description; INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('1', '-1', '1', 'Uncategorized');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('3', '1', '1', 'Canolive');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('5', '2', '1', 'Cooking oil');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('9', '4', '1', 'Unilever');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('11', '5', '1', 'Knorr');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('13', '6', '1', 'Dove');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('15', '7', '1', 'Lifebuoy');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('17', '8', '1', 'Shampoo');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('19', '9', '1', 'Tetra Pak');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('21', '10', '1', 'National Foods');


INSERT INTO categories_description (`categories_description_id`, `categories_id`, `language_id`, `categories_name`); VALUES ('23', '11', '1', 'PepsiCo');


TRUNCATE categories_role; TRUNCATE compare; TRUNCATE constant_banners; INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('1', '1', '', '146', '2020-12-18 11:28:04', '1', '1', '1');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('2', 'style0', '', '114', '2019-09-08 18:43:25', '1', '1', '2');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('3', 'banner1', '', '83', '2019-09-08 18:43:34', '1', '1', '3');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('4', 'banner1', '', '83', '2019-09-08 18:43:42', '1', '1', '4');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('5', 'banner1', '', '83', '2019-09-08 18:44:15', '1', '1', '5');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('6', 'banner2_3_4', '', '84', '2019-09-10 08:50:55', '1', '1', '6');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('7', 'banner2_3_4', '', '85', '2019-09-10 08:54:18', '1', '1', '7');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('8', 'banner2_3_4', '', '86', '2019-09-10 08:54:28', '1', '1', '8');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('9', 'banner2_3_4', '', '86', '2019-09-10 08:54:38', '1', '1', '9');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('10', 'banner5_6', '', '92', '2019-09-10 09:31:13', '1', '1', '10');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('11', 'banner5_6', '', '92', '2019-09-10 09:31:24', '1', '1', '11');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('12', 'banner5_6', '', '92', '2019-09-10 09:31:35', '1', '1', '12');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('13', 'banner5_6', '', '92', '2019-09-10 09:32:18', '1', '1', '13');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('14', 'banner5_6', '', '91', '2019-09-10 09:32:28', '1', '1', '14');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('15', 'banner7_8', '', '95', '2019-09-10 09:52:02', '1', '1', '15');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('16', 'banner7_8', '', '96', '2019-09-10 09:52:29', '1', '1', '16');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('17', 'banner7_8', '', '96', '2019-09-10 09:47:56', '1', '1', '17');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('18', 'banner7_8', '', '94', '2019-09-10 09:48:05', '1', '1', '18');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('19', 'banner9', '', '97', '2019-09-10 10:19:03', '1', '1', '19');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('20', 'banner9', '', '97', '2019-09-10 10:19:13', '1', '1', '20');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('21', 'banner10_11_12', '', '98', '2019-09-10 10:26:12', '1', '1', '21');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('22', 'banner10_11_12', '', '96', '2019-09-10 10:26:30', '1', '1', '22');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('23', 'banner10_11_12', '', '96', '2019-09-10 10:26:41', '1', '1', '23');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('24', 'banner10_11_12', '', '99', '2019-09-10 10:26:54', '1', '1', '24');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('25', 'banner13_14_15', '', '100', '2019-09-10 11:01:09', '1', '1', '25');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('26', 'banner13_14_15', '', '101', '2019-09-10 11:01:27', '1', '1', '26');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('27', 'banner13_14_15', '', '101', '2019-09-10 11:02:12', '1', '1', '27');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('28', 'banner13_14_15', '', '101', '2019-09-10 11:02:23', '1', '1', '28');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('29', 'banner13_14_15', '', '101', '2019-09-10 11:02:36', '1', '1', '29');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('30', 'banner16_17', '', '104', '2019-09-10 11:19:45', '1', '1', '30');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('31', 'banner16_17', '', '104', '2019-09-10 11:19:58', '1', '1', '31');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('32', 'banner16_17', '', '105', '2019-09-10 11:21:00', '1', '1', '32');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('33', 'banner18_19', '', '116', '2019-09-10 11:30:35', '1', '1', '33');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('34', 'banner18_19', '', '116', '2019-09-10 11:30:49', '1', '1', '34');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('35', 'banner18_19', '', '96', '2019-09-10 11:31:04', '1', '1', '35');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('36', 'banner18_19', '', '96', '2019-09-10 11:31:20', '1', '1', '36');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('37', 'banner18_19', '', '115', '2019-09-10 11:31:54', '1', '1', '37');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('38', 'banner18_19', '', '115', '2019-09-10 11:32:06', '1', '1', '38');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('39', 'ad_banner1', '', '107', '2019-09-11 06:17:45', '1', '1', '39');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('40', 'ad_banner2', '', '106', '2019-09-11 06:17:58', '1', '1', '40');


INSERT INTO constant_banners (`banners_id`, `banners_title`, `banners_url`, `banners_image`, `date_added`, `status`, `languages_id`, `type`); VALUES ('81', 'ad_banner3', '', '107', '0000-00-00 00:00:00', '1', '1', '41');


TRUNCATE countries; INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('1', 'Afghanistan', 'AF', 'AFG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('2', 'Albania', 'AL', 'ALB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('3', 'Algeria', 'DZ', 'DZA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('4', 'American Samoa', 'AS', 'ASM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('5', 'Andorra', 'AD', 'AND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('6', 'Angola', 'AO', 'AGO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('7', 'Anguilla', 'AI', 'AIA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('8', 'Antarctica', 'AQ', 'ATA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('9', 'Antigua and Barbuda', 'AG', 'ATG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('10', 'Argentina', 'AR', 'ARG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('11', 'Armenia', 'AM', 'ARM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('12', 'Aruba', 'AW', 'ABW', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('13', 'Australia', 'AU', 'AUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('14', 'Austria', 'AT', 'AUT', '5', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('15', 'Azerbaijan', 'AZ', 'AZE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('16', 'Bahamas', 'BS', 'BHS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('17', 'Bahrain', 'BH', 'BHR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('18', 'Bangladesh', 'BD', 'BGD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('19', 'Barbados', 'BB', 'BRB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('20', 'Belarus', 'BY', 'BLR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('21', 'Belgium', 'BE', 'BEL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('22', 'Belize', 'BZ', 'BLZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('23', 'Benin', 'BJ', 'BEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('24', 'Bermuda', 'BM', 'BMU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('25', 'Bhutan', 'BT', 'BTN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('26', 'Bolivia', 'BO', 'BOL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('27', 'Bosnia and Herzegowina', 'BA', 'BIH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('28', 'Botswana', 'BW', 'BWA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('29', 'Bouvet Island', 'BV', 'BVT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('30', 'Brazil', 'BR', 'BRA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('31', 'British Indian Ocean Territory', 'IO', 'IOT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('32', 'Brunei Darussalam', 'BN', 'BRN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('33', 'Bulgaria', 'BG', 'BGR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('34', 'Burkina Faso', 'BF', 'BFA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('35', 'Burundi', 'BI', 'BDI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('36', 'Cambodia', 'KH', 'KHM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('37', 'Cameroon', 'CM', 'CMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('38', 'Canada', 'CA', 'CAN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('39', 'Cape Verde', 'CV', 'CPV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('40', 'Cayman Islands', 'KY', 'CYM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('41', 'Central African Republic', 'CF', 'CAF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('42', 'Chad', 'TD', 'TCD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('43', 'Chile', 'CL', 'CHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('44', 'China', 'CN', 'CHN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('45', 'Christmas Island', 'CX', 'CXR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('46', 'Cocos (Keeling) Islands', 'CC', 'CCK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('47', 'Colombia', 'CO', 'COL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('48', 'Comoros', 'KM', 'COM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('49', 'Congo', 'CG', 'COG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('50', 'Cook Islands', 'CK', 'COK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('51', 'Costa Rica', 'CR', 'CRI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('52', 'Cote D\'Ivoire', 'CI', 'CIV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('53', 'Croatia', 'HR', 'HRV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('54', 'Cuba', 'CU', 'CUB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('55', 'Cyprus', 'CY', 'CYP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('56', 'Czech Republic', 'CZ', 'CZE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('57', 'Denmark', 'DK', 'DNK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('58', 'Djibouti', 'DJ', 'DJI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('59', 'Dominica', 'DM', 'DMA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('60', 'Dominican Republic', 'DO', 'DOM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('61', 'East Timor', 'TP', 'TMP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('62', 'Ecuador', 'EC', 'ECU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('63', 'Egypt', 'EG', 'EGY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('64', 'El Salvador', 'SV', 'SLV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('65', 'Equatorial Guinea', 'GQ', 'GNQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('66', 'Eritrea', 'ER', 'ERI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('67', 'Estonia', 'EE', 'EST', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('68', 'Ethiopia', 'ET', 'ETH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('69', 'Falkland Islands (Malvinas)', 'FK', 'FLK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('70', 'Faroe Islands', 'FO', 'FRO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('71', 'Fiji', 'FJ', 'FJI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('72', 'Finland', 'FI', 'FIN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('73', 'France', 'FR', 'FRA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('74', 'France, Metropolitan', 'FX', 'FXX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('75', 'French Guiana', 'GF', 'GUF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('76', 'French Polynesia', 'PF', 'PYF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('77', 'French Southern Territories', 'TF', 'ATF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('78', 'Gabon', 'GA', 'GAB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('79', 'Gambia', 'GM', 'GMB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('80', 'Georgia', 'GE', 'GEO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('81', 'Germany', 'DE', 'DEU', '5', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('82', 'Ghana', 'GH', 'GHA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('83', 'Gibraltar', 'GI', 'GIB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('84', 'Greece', 'GR', 'GRC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('85', 'Greenland', 'GL', 'GRL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('86', 'Grenada', 'GD', 'GRD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('87', 'Guadeloupe', 'GP', 'GLP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('88', 'Guam', 'GU', 'GUM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('89', 'Guatemala', 'GT', 'GTM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('90', 'Guinea', 'GN', 'GIN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('91', 'Guinea-bissau', 'GW', 'GNB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('92', 'Guyana', 'GY', 'GUY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('93', 'Haiti', 'HT', 'HTI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('94', 'Heard and Mc Donald Islands', 'HM', 'HMD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('95', 'Honduras', 'HN', 'HND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('96', 'Hong Kong', 'HK', 'HKG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('97', 'Hungary', 'HU', 'HUN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('98', 'Iceland', 'IS', 'ISL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('99', 'India', 'IN', 'IND', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('100', 'Indonesia', 'ID', 'IDN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('101', 'Iran (Islamic Republic of)', 'IR', 'IRN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('102', 'Iraq', 'IQ', 'IRQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('103', 'Ireland', 'IE', 'IRL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('104', 'Israel', 'IL', 'ISR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('105', 'Italy', 'IT', 'ITA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('106', 'Jamaica', 'JM', 'JAM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('107', 'Japan', 'JP', 'JPN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('108', 'Jordan', 'JO', 'JOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('109', 'Kazakhstan', 'KZ', 'KAZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('110', 'Kenya', 'KE', 'KEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('111', 'Kiribati', 'KI', 'KIR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('112', 'Korea, Democratic People\'s Republic of', 'KP', 'PRK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('113', 'Korea, Republic of', 'KR', 'KOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('114', 'Kuwait', 'KW', 'KWT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('115', 'Kyrgyzstan', 'KG', 'KGZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('116', 'Lao People\'s Democratic Republic', 'LA', 'LAO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('117', 'Latvia', 'LV', 'LVA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('118', 'Lebanon', 'LB', 'LBN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('119', 'Lesotho', 'LS', 'LSO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('120', 'Liberia', 'LR', 'LBR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('121', 'Libyan Arab Jamahiriya', 'LY', 'LBY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('122', 'Liechtenstein', 'LI', 'LIE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('123', 'Lithuania', 'LT', 'LTU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('124', 'Luxembourg', 'LU', 'LUX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('125', 'Macau', 'MO', 'MAC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('126', 'Macedonia, The Former Yugoslav Republic of', 'MK', 'MKD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('127', 'Madagascar', 'MG', 'MDG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('128', 'Malawi', 'MW', 'MWI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('129', 'Malaysia', 'MY', 'MYS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('130', 'Maldives', 'MV', 'MDV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('131', 'Mali', 'ML', 'MLI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('132', 'Malta', 'MT', 'MLT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('133', 'Marshall Islands', 'MH', 'MHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('134', 'Martinique', 'MQ', 'MTQ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('135', 'Mauritania', 'MR', 'MRT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('136', 'Mauritius', 'MU', 'MUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('137', 'Mayotte', 'YT', 'MYT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('138', 'Mexico', 'MX', 'MEX', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('139', 'Micronesia, Federated States of', 'FM', 'FSM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('140', 'Moldova, Republic of', 'MD', 'MDA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('141', 'Monaco', 'MC', 'MCO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('142', 'Mongolia', 'MN', 'MNG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('143', 'Montserrat', 'MS', 'MSR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('144', 'Morocco', 'MA', 'MAR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('145', 'Mozambique', 'MZ', 'MOZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('146', 'Myanmar', 'MM', 'MMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('147', 'Namibia', 'NA', 'NAM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('148', 'Nauru', 'NR', 'NRU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('149', 'Nepal', 'NP', 'NPL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('150', 'Netherlands', 'NL', 'NLD', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('151', 'Netherlands Antilles', 'AN', 'ANT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('152', 'New Caledonia', 'NC', 'NCL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('153', 'New Zealand', 'NZ', 'NZL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('154', 'Nicaragua', 'NI', 'NIC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('155', 'Niger', 'NE', 'NER', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('156', 'Nigeria', 'NG', 'NGA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('157', 'Niue', 'NU', 'NIU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('158', 'Norfolk Island', 'NF', 'NFK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('159', 'Northern Mariana Islands', 'MP', 'MNP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('160', 'Norway', 'NO', 'NOR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('161', 'Oman', 'OM', 'OMN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('162', 'Pakistan', 'PK', 'PAK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('163', 'Palau', 'PW', 'PLW', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('164', 'Panama', 'PA', 'PAN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('165', 'Papua New Guinea', 'PG', 'PNG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('166', 'Paraguay', 'PY', 'PRY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('167', 'Peru', 'PE', 'PER', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('168', 'Philippines', 'PH', 'PHL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('169', 'Pitcairn', 'PN', 'PCN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('170', 'Poland', 'PL', 'POL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('171', 'Portugal', 'PT', 'PRT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('172', 'Puerto Rico', 'PR', 'PRI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('173', 'Qatar', 'QA', 'QAT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('174', 'Reunion', 'RE', 'REU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('175', 'Romania', 'RO', 'ROM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('176', 'Russian Federation', 'RU', 'RUS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('177', 'Rwanda', 'RW', 'RWA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('178', 'Saint Kitts and Nevis', 'KN', 'KNA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('179', 'Saint Lucia', 'LC', 'LCA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('180', 'Saint Vincent and the Grenadines', 'VC', 'VCT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('181', 'Samoa', 'WS', 'WSM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('182', 'San Marino', 'SM', 'SMR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('183', 'Sao Tome and Principe', 'ST', 'STP', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('184', 'Saudi Arabia', 'SA', 'SAU', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('185', 'Senegal', 'SN', 'SEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('186', 'Seychelles', 'SC', 'SYC', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('187', 'Sierra Leone', 'SL', 'SLE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('188', 'Singapore', 'SG', 'SGP', '4', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('189', 'Slovakia (Slovak Republic)', 'SK', 'SVK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('190', 'Slovenia', 'SI', 'SVN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('191', 'Solomon Islands', 'SB', 'SLB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('192', 'Somalia', 'SO', 'SOM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('193', 'South Africa', 'ZA', 'ZAF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('194', 'South Georgia and the South Sandwich Islands', 'GS', 'SGS', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('195', 'Spain', 'ES', 'ESP', '3', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('196', 'Sri Lanka', 'LK', 'LKA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('197', 'St. Helena', 'SH', 'SHN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('198', 'St. Pierre and Miquelon', 'PM', 'SPM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('199', 'Sudan', 'SD', 'SDN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('200', 'Suriname', 'SR', 'SUR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('201', 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('202', 'Swaziland', 'SZ', 'SWZ', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('203', 'Sweden', 'SE', 'SWE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('204', 'Switzerland', 'CH', 'CHE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('205', 'Syrian Arab Republic', 'SY', 'SYR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('206', 'Taiwan', 'TW', 'TWN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('207', 'Tajikistan', 'TJ', 'TJK', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('208', 'Tanzania, United Republic of', 'TZ', 'TZA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('209', 'Thailand', 'TH', 'THA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('210', 'Togo', 'TG', 'TGO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('211', 'Tokelau', 'TK', 'TKL', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('212', 'Tonga', 'TO', 'TON', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('213', 'Trinidad and Tobago', 'TT', 'TTO', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('214', 'Tunisia', 'TN', 'TUN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('215', 'Turkey', 'TR', 'TUR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('216', 'Turkmenistan', 'TM', 'TKM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('217', 'Turks and Caicos Islands', 'TC', 'TCA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('218', 'Tuvalu', 'TV', 'TUV', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('219', 'Uganda', 'UG', 'UGA', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('220', 'Ukraine', 'UA', 'UKR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('221', 'United Arab Emirates', 'AE', 'ARE', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('222', 'United Kingdom', 'GB', 'GBR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('223', 'United States', 'US', 'USA', '2', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('224', 'United States Minor Outlying Islands', 'UM', 'UMI', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('225', 'Uruguay', 'UY', 'URY', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('226', 'Uzbekistan', 'UZ', 'UZB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('227', 'Vanuatu', 'VU', 'VUT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('228', 'Vatican City State (Holy See)', 'VA', 'VAT', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('229', 'Venezuela', 'VE', 'VEN', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('230', 'Viet Nam', 'VN', 'VNM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('231', 'Virgin Islands (British)', 'VG', 'VGB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('232', 'Virgin Islands (U.S.)', 'VI', 'VIR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('233', 'Wallis and Futuna Islands', 'WF', 'WLF', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('234', 'Western Sahara', 'EH', 'ESH', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('235', 'Yemen', 'YE', 'YEM', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('236', 'Yugoslavia', 'YU', 'YUG', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('237', 'Zaire', 'ZR', 'ZAR', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('238', 'Zambia', 'ZM', 'ZMB', '1', '');


INSERT INTO countries (`countries_id`, `countries_name`, `countries_iso_code_2`, `countries_iso_code_3`, `address_format_id`, `country_code`); VALUES ('239', 'Zimbabwe', 'ZW', 'ZWE', '1', '');


TRUNCATE coupons; INSERT INTO coupons (`coupans_id`, `code`, `date_created`, `date_modified`, `description`, `discount_type`, `amount`, `expiry_date`, `usage_count`, `individual_use`, `product_ids`, `exclude_product_ids`, `usage_limit`, `usage_limit_per_user`, `limit_usage_to_x_items`, `free_shipping`, `product_categories`, `excluded_product_categories`, `exclude_sale_items`, `minimum_amount`, `maximum_amount`, `email_restrictions`, `used_by`, `created_at`, `updated_at`); VALUES ('1', 'NEW', '', '', '', 'percent_product', '1000', '2020-12-31 00:00:00', '0', '0', '1,2', '', '', '', '0', '1', '', '', '0', '1.00', '2.00', '', '', '2020-12-18 14:44:50', '');


TRUNCATE currencies; INSERT INTO currencies (`id`, `title`, `code`, `symbol_left`, `symbol_right`, `decimal_point`, `thousands_point`, `decimal_places`, `created_at`, `updated_at`, `value`, `is_default`, `status`, `is_current`); VALUES ('1', 'P.K. Rupee', 'PKR', 'Rs', '', '', '', '2', '2019-09-06 08:33:11', '2019-09-06 08:33:11', '1', '1', '1', '1');


TRUNCATE currency_record; INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('1', 'AED', 'United Arab Emirates Dirham');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('2', 'AFN', 'Afghan Afghani');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('3', 'ALL', 'Albanian Lek');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('4', 'AMD', 'Armenian Dram');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('5', 'ANG', 'Netherlands Antillean Guilder');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('6', 'AOA', 'Angolan Kwanza');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('7', 'ARS', 'Argentine Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('8', 'AUD', 'Australian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('9', 'AWG', 'Aruban Florin');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('10', 'AZN', 'Azerbaijani Manat');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('11', 'BAM', 'Bosnia-Herzegovina Convertible Mark');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('12', 'BBD', 'Barbadian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('13', 'BDT', 'Bangladeshi Taka');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('14', 'BGN', 'Bulgarian Lev');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('15', 'BHD', 'Bahraini Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('16', 'BIF', 'Burundian Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('17', 'BMD', 'Bermudan Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('18', 'BND', 'Brunei Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('19', 'BOB', 'Bolivian Boliviano');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('20', 'BRL', 'Brazilian Real');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('21', 'BSD', 'Bahamian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('22', 'BTC', 'Bitcoin');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('23', 'BTN', 'Bhutanese Ngultrum');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('24', 'BWP', 'Botswanan Pula');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('25', 'BYN', 'Belarusian Ruble');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('26', 'BZD', 'Belize Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('27', 'CAD', 'Canadian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('28', 'CDF', 'Congolese Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('29', 'CHF', 'Swiss Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('30', 'CLF', 'Chilean Unit of Account (UF)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('31', 'CLP', 'Chilean Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('32', 'CNH', 'Chinese Yuan (Offshore)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('33', 'CNY', 'Chinese Yuan');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('34', 'COP', 'Colombian Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('35', 'CRC', 'Costa Rican Colón');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('36', 'CUC', 'Cuban Convertible Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('37', 'CUP', 'Cuban Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('38', 'CVE', 'Cape Verdean Escudo');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('39', 'CZK', 'Czech Republic Koruna');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('40', 'DJF', 'Djiboutian Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('41', 'DKK', 'Danish Krone');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('42', 'DOP', 'Dominican Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('43', 'DZD', 'Algerian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('44', 'EGP', 'Egyptian Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('45', 'ERN', 'Eritrean Nakfa');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('46', 'ETB', 'Ethiopian Birr');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('47', 'EUR', 'Euro');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('48', 'FJD', 'Fijian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('49', 'FKP', 'Falkland Islands Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('50', 'GBP', 'British Pound Sterling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('51', 'GEL', 'Georgian Lari');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('52', 'GGP', 'Guernsey Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('53', 'GHS', 'Ghanaian Cedi');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('54', 'GIP', 'Gibraltar Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('55', 'GMD', 'Gambian Dalasi');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('56', 'GNF', 'Guinean Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('57', 'GTQ', 'Guatemalan Quetzal');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('58', 'GYD', 'Guyanaese Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('59', 'HKD', 'Hong Kong Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('60', 'HNL', 'Honduran Lempira');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('61', 'HRK', 'Croatian Kuna');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('62', 'HTG', 'Haitian Gourde');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('63', 'HUF', 'Hungarian Forint');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('64', 'IDR', 'Indonesian Rupiah');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('65', 'ILS', 'Israeli New Sheqel');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('66', 'IMP', 'Manx pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('67', 'INR', 'Indian Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('68', 'IQD', 'Iraqi Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('69', 'IRR', 'Iranian Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('70', 'ISK', 'Icelandic Króna');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('71', 'JEP', 'Jersey Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('72', 'JMD', 'Jamaican Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('73', 'JOD', 'Jordanian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('74', 'JPY', 'Japanese Yen');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('75', 'KES', 'Kenyan Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('76', 'KGS', 'Kyrgystani Som');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('77', 'KHR', 'Cambodian Riel');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('78', 'KMF', 'Comorian Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('79', 'KPW', 'North Korean Won');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('80', 'KRW', 'South Korean Won');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('81', 'KWD', 'Kuwaiti Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('82', 'KYD', 'Cayman Islands Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('83', 'KZT', 'Kazakhstani Tenge');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('84', 'LAK', 'Laotian Kip');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('85', 'LBP', 'Lebanese Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('86', 'LKR', 'Sri Lankan Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('87', 'LRD', 'Liberian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('88', 'LSL', 'Lesotho Loti');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('89', 'LYD', 'Libyan Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('90', 'MAD', 'Moroccan Dirham');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('91', 'MDL', 'Moldovan Leu');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('92', 'MGA', 'Malagasy Ariary');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('93', 'MKD', 'Macedonian Denar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('94', 'MMK', 'Myanma Kyat');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('95', 'MNT', 'Mongolian Tugrik');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('96', 'MOP', 'Macanese Pataca');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('97', 'MRO', 'Mauritanian Ouguiya (pre-2018)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('98', 'MRU', 'Mauritanian Ouguiya');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('99', 'MUR', 'Mauritian Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('100', 'MVR', 'Maldivian Rufiyaa');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('101', 'MWK', 'Malawian Kwacha');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('102', 'MXN', 'Mexican Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('103', 'MYR', 'Malaysian Ringgit');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('104', 'MZN', 'Mozambican Metical');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('105', 'NAD', 'Namibian Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('106', 'NGN', 'Nigerian Naira');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('107', 'NIO', 'Nicaraguan Córdoba');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('108', 'NOK', 'Norwegian Krone');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('109', 'NPR', 'Nepalese Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('110', 'NZD', 'New Zealand Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('111', 'OMR', 'Omani Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('112', 'PAB', 'Panamanian Balboa');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('113', 'PEN', 'Peruvian Nuevo Sol');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('114', 'PGK', 'Papua New Guinean Kina');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('115', 'PHP', 'Philippine Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('116', 'PKR', 'Pakistani Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('117', 'PLN', 'Polish Zloty');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('118', 'PYG', 'Paraguayan Guarani');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('119', 'QAR', 'Qatari Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('120', 'RON', 'Romanian Leu');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('121', 'RSD', 'Serbian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('122', 'RUB', 'Russian Ruble');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('123', 'RWF', 'Rwandan Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('124', 'SAR', 'Saudi Riyal');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('125', 'SBD', 'Solomon Islands Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('126', 'SCR', 'Seychellois Rupee');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('127', 'SDG', 'Sudanese Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('128', 'SEK', 'Swedish Krona');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('129', 'SGD', 'Singapore Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('130', 'SHP', 'Saint Helena Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('131', 'SLL', 'Sierra Leonean Leone');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('132', 'SOS', 'Somali Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('133', 'SRD', 'Surinamese Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('134', 'SSP', 'South Sudanese Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('135', 'STD', 'São Tomé and Príncipe Dobra (pre-2018)');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('136', 'STN', 'São Tomé and Príncipe Dobra');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('137', 'SVC', 'Salvadoran Colón');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('138', 'SYP', 'Syrian Pound');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('139', 'SZL', 'Swazi Lilangeni');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('140', 'THB', 'Thai Baht');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('141', 'TJS', 'Tajikistani Somoni');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('142', 'TMT', 'Turkmenistani Manat');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('143', 'TND', 'Tunisian Dinar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('144', 'TOP', 'Tongan Pa\'anga');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('145', 'TRY', 'Turkish Lira');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('146', 'TTD', 'Trinidad and Tobago Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('147', 'TWD', 'New Taiwan Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('148', 'TZS', 'Tanzanian Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('149', 'UAH', 'Ukrainian Hryvnia');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('150', 'UGX', 'Ugandan Shilling');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('151', 'USD', 'United States Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('152', 'UYU', 'Uruguayan Peso');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('153', 'UZS', 'Uzbekistan Som');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('154', 'VEF', 'Venezuelan Bolívar Fuerte');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('155', 'VND', 'Vietnamese Dong');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('156', 'VUV', 'Vanuatu Vatu');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('157', 'WST', 'Samoan Tala');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('158', 'XAF', 'CFA Franc BEAC');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('159', 'XAG', 'Silver Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('160', 'XAU', 'Gold Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('161', 'XCD', 'East Caribbean Dollar');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('162', 'XDR', 'Special Drawing Rights');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('163', 'XOF', 'CFA Franc BCEAO');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('164', 'XPD', 'Palladium Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('165', 'XPF', 'CFP Franc');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('166', 'XPT', 'Platinum Ounce');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('167', 'YER', 'Yemeni Rial');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('168', 'ZAR', 'South African Rand');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('169', 'ZMW', 'Zambian Kwacha');


INSERT INTO currency_record (`id`, `code`, `currency_name`); VALUES ('170', 'ZWL', 'Zimbabwean Dollar');


TRUNCATE current_theme; INSERT INTO current_theme (`id`, `top_offer`, `header`, `carousel`, `banner`, `footer`, `product_section_order`, `cart`, `news`, `detail`, `shop`, `contact`, `login`, `transitions`, `banner_two`); VALUES ('1', '1', '2', '3', '1', '10', '[{\"id\":10,\"name\":\"Second Ad Section\",\"order\":1,\"file_name\":\"sec_ad_banner\",\"status\":0,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Second Ad Section\"},{\"id\":5,\"name\":\"Categories\",\"order\":2,\"file_name\":\"categories\",\"status\":1,\"image\":\"images\\/prototypes\\/categories.jpg\",\"disabled_image\":\"images\\/prototypes\\/categories-cross.jpg\",\"alt\":\"Categories\"},{\"id\":1,\"name\":\"Banner Section\",\"order\":3,\"file_name\":\"banner_section\",\"status\":0,\"image\":\"images\\/prototypes\\/banner_section.jpg\",\"alt\":\"Banner Section\"},{\"id\":11,\"name\":\"Tab Products View\",\"order\":4,\"file_name\":\"tab\",\"status\":1,\"image\":\"images\\/prototypes\\/tab.jpg\",\"disabled_image\":\"images\\/prototypes\\/tab-cross.jpg\",\"alt\":\"Tab Products View\"},{\"id\":9,\"name\":\"Top Selling\",\"order\":5,\"file_name\":\"top\",\"status\":1,\"image\":\"images\\/prototypes\\/top.jpg\",\"disabled_image\":\"images\\/prototypes\\/top-cross.jpg\",\"alt\":\"Top Selling\"},{\"id\":8,\"name\":\"Newest Product Section\",\"order\":6,\"file_name\":\"newest_product\",\"status\":1,\"image\":\"images\\/prototypes\\/newest_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/newest_product-cross.jpg\",\"alt\":\"Newest Product Section\"},{\"id\":3,\"name\":\"Special Products Section\",\"order\":7,\"file_name\":\"special\",\"status\":1,\"image\":\"images\\/prototypes\\/special_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/special_product-cross.jpg\",\"alt\":\"Special Products Section\"},{\"id\":2,\"name\":\"Flash Sale Section\",\"order\":8,\"file_name\":\"flash_sale_section\",\"status\":1,\"image\":\"images\\/prototypes\\/flash_sale_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/flash_sale_section-cross.jpg\",\"alt\":\"Flash Sale Section\"},{\"id\":4,\"name\":\"Ad Section\",\"order\":9,\"file_name\":\"ad_banner_section\",\"status\":0,\"image\":\"images\\/prototypes\\/ad_banner_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/ad_banner_section-cross.jpg\",\"alt\":\"Ad Section\"},{\"id\":6,\"name\":\"Blog Section\",\"order\":10,\"file_name\":\"blog_section\",\"status\":0,\"image\":\"images\\/prototypes\\/blog_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/blog_section-cross.jpg\",\"alt\":\"Blog Section\"},{\"id\":12,\"name\":\"Banner 2 Section\",\"order\":11,\"file_name\":\"banner_two_section\",\"status\":0,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Banner 2 Section\"},{\"id\":7,\"name\":\"Info Boxes\",\"order\":12,\"file_name\":\"info_boxes\",\"status\":1,\"image\":\"images\\/prototypes\\/info_boxes.jpg\",\"disabled_image\":\"images\\/prototypes\\/info_boxes-cross.jpg\",\"alt\":\"Info Boxes\"}]', '1', '1', '4', '1', '1', '2', '3', '1');


TRUNCATE customers; TRUNCATE customers_basket; INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('1', '2', '1', '1', '320.00', '2020-12-18', '1', 'dlegdgcwOb8lzkXdiuNtGq5wYW4161a2pvxgxEJG');


INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('2', '2', '1', '2', '320.00', '2020-12-18', '1', 'OhN6ztKcv6keHHGAfce6vPN8VejMZZ0cTV2tgvsW');


INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('8', '0', '2', '1', '269.00', '2020-12-18', '0', 'JoI23dofHJzvhBKd8JYSnqpB9sNbgu9LOn6Jr8du');


INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('9', '2', '2', '1', '160.00', '2020-12-21', '1', 'Y7uuw4MrPa6bEFee12nGkJtVoCASa1XJU0abSFew');


INSERT INTO customers_basket (`customers_basket_id`, `customers_id`, `products_id`, `customers_basket_quantity`, `final_price`, `customers_basket_date_added`, `is_order`, `session_id`); VALUES ('10', '3', '2', '1', '160.00', '2020-12-21', '0', 'P9m0bPzKasd2ZDKQvwB1zAfzwgVh9Y35cI1ZWhYa');


TRUNCATE customers_basket_attributes; INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('1', '1', '2', '1', '1', '1', 'dlegdgcwOb8lzkXdiuNtGq5wYW4161a2pvxgxEJG');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('2', '2', '2', '1', '1', '1', 'OhN6ztKcv6keHHGAfce6vPN8VejMZZ0cTV2tgvsW');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('10', '8', '0', '2', '1', '1', 'JoI23dofHJzvhBKd8JYSnqpB9sNbgu9LOn6Jr8du');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('11', '8', '0', '2', '2', '3', 'JoI23dofHJzvhBKd8JYSnqpB9sNbgu9LOn6Jr8du');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('12', '8', '0', '2', '3', '6', 'JoI23dofHJzvhBKd8JYSnqpB9sNbgu9LOn6Jr8du');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('13', '9', '2', '2', '1', '1', 'Y7uuw4MrPa6bEFee12nGkJtVoCASa1XJU0abSFew');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('14', '9', '2', '2', '2', '3', 'Y7uuw4MrPa6bEFee12nGkJtVoCASa1XJU0abSFew');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('15', '9', '2', '2', '3', '6', 'Y7uuw4MrPa6bEFee12nGkJtVoCASa1XJU0abSFew');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('16', '10', '3', '2', '1', '1', 'P9m0bPzKasd2ZDKQvwB1zAfzwgVh9Y35cI1ZWhYa');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('17', '10', '3', '2', '2', '3', 'P9m0bPzKasd2ZDKQvwB1zAfzwgVh9Y35cI1ZWhYa');


INSERT INTO customers_basket_attributes (`customers_basket_attributes_id`, `customers_basket_id`, `customers_id`, `products_id`, `products_options_id`, `products_options_values_id`, `session_id`); VALUES ('18', '10', '3', '2', '3', '6', 'P9m0bPzKasd2ZDKQvwB1zAfzwgVh9Y35cI1ZWhYa');


TRUNCATE customers_info; TRUNCATE devices; TRUNCATE flash_sale; TRUNCATE flate_rate; INSERT INTO flate_rate (`id`, `flate_rate`, `currency`); VALUES ('1', '200', 'PKR');


TRUNCATE front_end_theme_content; INSERT INTO front_end_theme_content (`id`, `top_offers`, `headers`, `carousels`, `banners`, `footers`, `product_section_order`, `cart`, `news`, `detail`, `shop`, `contact`, `login`, `transitions`, `banners_two`); VALUES ('1', '', '[
{
\"id\": 1,
\"name\": \"Header One\",
\"image\": \"images/prototypes/header1.jpg\",
\"alt\" : \"header One\" 
},
{
\"id\": 2,
\"name\": \"Header Two\",
\"image\": \"images/prototypes/header2.jpg\",
\"alt\" : \"header Two\" 
},
{
\"id\": 3,
\"name\": \"Header Three\",
\"image\": \"images/prototypes/header3.jpg\",
\"alt\" : \"header Three\" 
},
{
\"id\": 4,
\"name\": \"Header Four\",
\"image\": \"images/prototypes/header4.jpg\",
\"alt\" : \"header Four\" 
},
{
\"id\": 5,
\"name\": \"Header Five\",
\"image\": \"images/prototypes/header5.jpg\",
\"alt\" : \"header Five\" 
},
{
\"id\": 6,
\"name\": \"Header Six\",
\"image\": \"images/prototypes/header6.jpg\",
\"alt\" : \"header Six\" 
},
{
\"id\": 7,
\"name\": \"Header Seven\",
\"image\": \"images/prototypes/header7.jpg\",
\"alt\" : \"header Seven\" 
},
{
\"id\": 8,
\"name\": \"Header Eight\",
\"image\": \"images/prototypes/header8.jpg\",
\"alt\" : \"header Eight\" 
},
{
\"id\": 9,
\"name\": \"Header Nine\",
\"image\": \"images/prototypes/header9.jpg\",
\"alt\" : \"header Nine\" 
},
{
\"id\": 10,
\"name\": \"Header Ten\",
\"image\": \"images/prototypes/header10.jpg\",
\"alt\" : \"header Ten\" 
}
]', '[
{
\"id\": 1,
\"name\": \"Bootstrap Carousel Content Full Screen\",
\"image\": \"images/prototypes/carousal1.jpg\",
\"alt\": \"Bootstrap Carousel Content Full Screen\"
},
{
\"id\": 2,
\"name\": \"Bootstrap Carousel Content Full Width\",
\"image\": \"images/prototypes/carousal2.jpg\",
\"alt\": \"Bootstrap Carousel Content Full Width\"
},
{
\"id\": 3,
\"name\": \"Bootstrap Carousel Content with Left Banner\",
\"image\": \"images/prototypes/carousal3.jpg\",
\"alt\": \"Bootstrap Carousel Content with Left Banner\"
},
{
\"id\": 4,
\"name\": \"Bootstrap Carousel Content with Navigation\",
\"image\": \"images/prototypes/carousal4.jpg\",
\"alt\": \"Bootstrap Carousel Content with Navigation\"
},
{
\"id\": 5,
\"name\": \"Bootstrap Carousel Content with Right Banner\",
\"image\": \"images/prototypes/carousal5.jpg\",
\"alt\": \"Bootstrap Carousel Content with Right Banner\"
}
]', '[
{
\"id\": 1,
\"name\": \"Banner One\",
\"image\": \"images/prototypes/banner1.jpg\",
\"alt\": \"Banner One\"
},
{
\"id\": 2,
\"name\": \"Banner Two\",
\"image\": \"images/prototypes/banner2.jpg\",
\"alt\": \"Banner Two\"
},
{
\"id\": 3,
\"name\": \"Banner Three\",
\"image\": \"images/prototypes/banner3.jpg\",
\"alt\": \"Banner Three\"
},
{
\"id\": 4,
\"name\": \"Banner Four\",
\"image\": \"images/prototypes/banner4.jpg\",
\"alt\": \"Banner Four\"
},
{
\"id\": 5,
\"name\": \"Banner Five\",
\"image\": \"images/prototypes/banner5.jpg\",
\"alt\": \"Banner Five\"
},
{
\"id\": 6,
\"name\": \"Banner Six\",
\"image\": \"images/prototypes/banner6.jpg\",
\"alt\": \"Banner Six\"
},
{
\"id\": 7,
\"name\": \"Banner Seven\",
\"image\": \"images/prototypes/banner7.jpg\",
\"alt\": \"Banner Seven\"
},
{
\"id\": 8,
\"name\": \"Banner Eight\",
\"image\": \"images/prototypes/banner8.jpg\",
\"alt\": \"Banner Eight\"
},
{
\"id\": 9,
\"name\": \"Banner Nine\",
\"image\": \"images/prototypes/banner9.jpg\",
\"alt\": \"Banner Nine\"
},
{
\"id\": 10,
\"name\": \"Banner Ten\",
\"image\": \"images/prototypes/banner10.jpg\",
\"alt\": \"Banner Ten\"
},
{
\"id\": 11,
\"name\": \"Banner Eleven\",
\"image\": \"images/prototypes/banner11.jpg\",
\"alt\": \"Banner Eleven\"
},
{
\"id\": 12,
\"name\": \"Banner Twelve\",
\"image\": \"images/prototypes/banner12.jpg\",
\"alt\": \"Banner Twelve\"
},
{
\"id\": 13,
\"name\": \"Banner Thirteen\",
\"image\": \"images/prototypes/banner13.jpg\",
\"alt\": \"Banner Thirteen\"
},
{
\"id\": 14,
\"name\": \"Banner Fourteen\",
\"image\": \"images/prototypes/banner14.jpg\",
\"alt\": \"Banner Fourteen\"
},
{
\"id\": 15,
\"name\": \"Banner Fifteen\",
\"image\": \"images/prototypes/banner15.jpg\",
\"alt\": \"Banner Fifteen\"
},
{
\"id\": 16,
\"name\": \"Banner Sixteen\",
\"image\": \"images/prototypes/banner16.jpg\",
\"alt\": \"Banner Sixteen\"
},
{
\"id\": 17,
\"name\": \"Banner Seventeen\",
\"image\": \"images/prototypes/banner17.jpg\",
\"alt\": \"Banner Seventeen\"
},
{
\"id\": 18,
\"name\": \"Banner Eighteen\",
\"image\": \"images/prototypes/banner18.jpg\",
\"alt\": \"Banner Eighteen\"
},
{
\"id\": 19,
\"name\": \"Banner Nineteen\",
\"image\": \"images/prototypes/banner19.jpg\",
\"alt\": \"Banner Nineteen\"
}
]', '[
{
\"id\": 1,
\"name\": \"Footer One\",
\"image\": \"images/prototypes/footer1.png\",
\"alt\" : \"Footer One\"
},
{
\"id\": 2,
\"name\": \"Footer Two\",
\"image\": \"images/prototypes/footer2.png\",
\"alt\" : \"Footer Two\"
},
{
\"id\": 3,
\"name\": \"Footer Three\",
\"image\": \"images/prototypes/footer3.png\",
\"alt\" : \"Footer Three\"
},
{
\"id\": 4,
\"name\": \"Footer Four\",
\"image\": \"images/prototypes/footer4.png\",
\"alt\" : \"Footer Four\"
},
{
\"id\": 5,
\"name\": \"Footer Five\",
\"image\": \"images/prototypes/footer5.png\",
\"alt\" : \"Footer Five\"
},
{
\"id\": 6,
\"name\": \"Footer Six\",
\"image\": \"images/prototypes/footer6.png\",
\"alt\" : \"Footer Six\"
},
{
\"id\": 7,
\"name\": \"Footer Seven\",
\"image\": \"images/prototypes/footer7.png\",
\"alt\" : \"Footer Seven\"
},
{
\"id\": 8,
\"name\": \"Footer Eight\",
\"image\": \"images/prototypes/footer8.png\",
\"alt\" : \"Footer Eight\"
},
{
\"id\": 9,
\"name\": \"Footer Nine\",
\"image\": \"images/prototypes/footer9.png\",
\"alt\" : \"Footer Nine\"
},
{
\"id\": 10,
\"name\": \"Footer Ten\",
\"image\": \"images/prototypes/footer10.png\",
\"alt\" : \"Footer Ten\"
}
]', '[{\"id\":10,\"name\":\"Second Ad Section\",\"order\":1,\"file_name\":\"sec_ad_banner\",\"status\":0,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Second Ad Section\"},{\"id\":5,\"name\":\"Categories\",\"order\":2,\"file_name\":\"categories\",\"status\":1,\"image\":\"images\\/prototypes\\/categories.jpg\",\"disabled_image\":\"images\\/prototypes\\/categories-cross.jpg\",\"alt\":\"Categories\"},{\"id\":1,\"name\":\"Banner Section\",\"order\":3,\"file_name\":\"banner_section\",\"status\":0,\"image\":\"images\\/prototypes\\/banner_section.jpg\",\"alt\":\"Banner Section\"},{\"id\":11,\"name\":\"Tab Products View\",\"order\":4,\"file_name\":\"tab\",\"status\":1,\"image\":\"images\\/prototypes\\/tab.jpg\",\"disabled_image\":\"images\\/prototypes\\/tab-cross.jpg\",\"alt\":\"Tab Products View\"},{\"id\":9,\"name\":\"Top Selling\",\"order\":5,\"file_name\":\"top\",\"status\":1,\"image\":\"images\\/prototypes\\/top.jpg\",\"disabled_image\":\"images\\/prototypes\\/top-cross.jpg\",\"alt\":\"Top Selling\"},{\"id\":8,\"name\":\"Newest Product Section\",\"order\":6,\"file_name\":\"newest_product\",\"status\":1,\"image\":\"images\\/prototypes\\/newest_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/newest_product-cross.jpg\",\"alt\":\"Newest Product Section\"},{\"id\":3,\"name\":\"Special Products Section\",\"order\":7,\"file_name\":\"special\",\"status\":1,\"image\":\"images\\/prototypes\\/special_product.jpg\",\"disabled_image\":\"images\\/prototypes\\/special_product-cross.jpg\",\"alt\":\"Special Products Section\"},{\"id\":2,\"name\":\"Flash Sale Section\",\"order\":8,\"file_name\":\"flash_sale_section\",\"status\":1,\"image\":\"images\\/prototypes\\/flash_sale_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/flash_sale_section-cross.jpg\",\"alt\":\"Flash Sale Section\"},{\"id\":4,\"name\":\"Ad Section\",\"order\":9,\"file_name\":\"ad_banner_section\",\"status\":0,\"image\":\"images\\/prototypes\\/ad_banner_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/ad_banner_section-cross.jpg\",\"alt\":\"Ad Section\"},{\"id\":6,\"name\":\"Blog Section\",\"order\":10,\"file_name\":\"blog_section\",\"status\":0,\"image\":\"images\\/prototypes\\/blog_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/blog_section-cross.jpg\",\"alt\":\"Blog Section\"},{\"id\":12,\"name\":\"Banner 2 Section\",\"order\":11,\"file_name\":\"banner_two_section\",\"status\":0,\"image\":\"images\\/prototypes\\/sec_ad_section.jpg\",\"disabled_image\":\"images\\/prototypes\\/sec_ad_section-cross.jpg\",\"alt\":\"Banner 2 Section\"},{\"id\":7,\"name\":\"Info Boxes\",\"order\":12,\"file_name\":\"info_boxes\",\"status\":1,\"image\":\"images\\/prototypes\\/info_boxes.jpg\",\"disabled_image\":\"images\\/prototypes\\/info_boxes-cross.jpg\",\"alt\":\"Info Boxes\"}]', '[      {         \"id\":1,       \"name\":\"Cart One\"    },    {         \"id\":2,       \"name\":\"Cart Two\"    }     ]', '[      {         \"id\":1,       \"name\":\"News One\"    },    {         \"id\":2,       \"name\":\"News Two\"    }     ]', '[  
{  
\"id\":1,
\"name\":\"Product Detail Page One\"
},
{  
\"id\":2,
\"name\":\"Product Detail Page Two\"
},
{  
\"id\":3,
\"name\":\"Product Detail Page Three\"
},
{  
\"id\":4,
\"name\":\"Product Detail Page Four\"
},
{  
\"id\":5,
\"name\":\"Product Detail Page Five\"
},
{  
\"id\":6,
\"name\":\"Product Detail Page Six\"
}

]', '[      {         \"id\":1,       \"name\":\"Shop Page One\"    },    {         \"id\":2,       \"name\":\"Shop Page Two\"    },    {         \"id\":3,       \"name\":\"Shop Page Three\"    },    {         \"id\":4,       \"name\":\"Shop Page Four\"    },    {         \"id\":5,       \"name\":\"Shop Page Five\"    }     ]', '[      {         \"id\":1,       \"name\":\"Contact Page One\"    },    {         \"id\":2,       \"name\":\"Contact Page Two\"    } ]', '[      {         \"id\":1,       \"name\":\"Login Page One\"    },    {         \"id\":2,       \"name\":\"Login Page Two\"    } ]', '[ { \"id\":1, \"name\":\"Transition Zoomin\" }, { \"id\":2, \"name\":\"Transition Flashing\" }, { \"id\":3, \"name\":\"Transition Shine\" }, { \"id\":4, \"name\":\"Transition Circle\" }, { \"id\":5, \"name\":\"Transition Opacity\" } ]', '[ { \"id\": 1, \"name\": \"Banner One\", \"image\": \"images/prototypes/banner1.jpg\", \"alt\": \"Banner One\" }, { \"id\": 2, \"name\": \"Banner Two\", \"image\": \"images/prototypes/banner2.jpg\", \"alt\": \"Banner Two\" }, { \"id\": 3, \"name\": \"Banner Three\", \"image\": \"images/prototypes/banner3.jpg\", \"alt\": \"Banner Three\" }, { \"id\": 4, \"name\": \"Banner Four\", \"image\": \"images/prototypes/banner4.jpg\", \"alt\": \"Banner Four\" }, { \"id\": 5, \"name\": \"Banner Five\", \"image\": \"images/prototypes/banner5.jpg\", \"alt\": \"Banner Five\" }, { \"id\": 6, \"name\": \"Banner Six\", \"image\": \"images/prototypes/banner6.jpg\", \"alt\": \"Banner Six\" }, { \"id\": 7, \"name\": \"Banner Seven\", \"image\": \"images/prototypes/banner7.jpg\", \"alt\": \"Banner Seven\" }, { \"id\": 8, \"name\": \"Banner Eight\", \"image\": \"images/prototypes/banner8.jpg\", \"alt\": \"Banner Eight\" }, { \"id\": 9, \"name\": \"Banner Nine\", \"image\": \"images/prototypes/banner9.jpg\", \"alt\": \"Banner Nine\" }, { \"id\": 10, \"name\": \"Banner Ten\", \"image\": \"images/prototypes/banner10.jpg\", \"alt\": \"Banner Ten\" }, { \"id\": 11, \"name\": \"Banner Eleven\", \"image\": \"images/prototypes/banner11.jpg\", \"alt\": \"Banner Eleven\" }, { \"id\": 12, \"name\": \"Banner Twelve\", \"image\": \"images/prototypes/banner12.jpg\", \"alt\": \"Banner Twelve\" }, { \"id\": 13, \"name\": \"Banner Thirteen\", \"image\": \"images/prototypes/banner13.jpg\", \"alt\": \"Banner Thirteen\" }, { \"id\": 14, \"name\": \"Banner Fourteen\", \"image\": \"images/prototypes/banner14.jpg\", \"alt\": \"Banner Fourteen\" }, { \"id\": 15, \"name\": \"Banner Fifteen\", \"image\": \"images/prototypes/banner15.jpg\", \"alt\": \"Banner Fifteen\" }, { \"id\": 16, \"name\": \"Banner Sixteen\", \"image\": \"images/prototypes/banner16.jpg\", \"alt\": \"Banner Sixteen\" }, { \"id\": 17, \"name\": \"Banner Seventeen\", \"image\": \"images/prototypes/banner17.jpg\", \"alt\": \"Banner Seventeen\" }, { \"id\": 18, \"name\": \"Banner Eighteen\", \"image\": \"images/prototypes/banner18.jpg\", \"alt\": \"Banner Eighteen\" }, { \"id\": 19, \"name\": \"Banner Nineteen\", \"image\": \"images/prototypes/banner19.jpg\", \"alt\": \"Banner Nineteen\" } ]');


TRUNCATE geo_zones; TRUNCATE home_banners; TRUNCATE http_call_record; TRUNCATE image_categories; INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('84', '83', 'ACTUAL', '277', '370', 'images/media/2019/10/JqYfZ11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('85', '83', 'THUMBNAIL', '112', '150', 'images/media/2019/10/thumbnail1570778231JqYfZ11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('86', '84', 'ACTUAL', '301', '770', 'images/media/2019/10/6Q4Qy11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('87', '85', 'ACTUAL', '550', '368', 'images/media/2019/10/jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('88', '85', 'THUMBNAIL', '150', '100', 'images/media/2019/10/thumbnail1570778446jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('89', '85', 'MEDIUM', '400', '268', 'images/media/2019/10/medium1570778446jOVnc11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('90', '86', 'ACTUAL', '220', '370', 'images/media/2019/10/Ake4A11107.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('91', '86', 'THUMBNAIL', '89', '150', 'images/media/2019/10/thumbnail1570778447Ake4A11107.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('96', '89', 'ACTUAL', '229', '270', 'images/media/2019/10/nDQtA11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('97', '89', 'THUMBNAIL', '127', '150', 'images/media/2019/10/thumbnail1570778680nDQtA11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('98', '90', 'ACTUAL', '298', '568', 'images/media/2019/10/ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('99', '90', 'THUMBNAIL', '79', '150', 'images/media/2019/10/thumbnail1570778749ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('100', '90', 'MEDIUM', '210', '400', 'images/media/2019/10/medium1570778749ueyod11407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('101', '91', 'ACTUAL', '490', '570', 'images/media/2019/10/xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('102', '91', 'THUMBNAIL', '129', '150', 'images/media/2019/10/thumbnail1570778967xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('103', '91', 'MEDIUM', '344', '400', 'images/media/2019/10/medium1570778967xD6MF11207.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('104', '92', 'ACTUAL', '229', '270', 'images/media/2019/10/YZyoU11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('105', '92', 'THUMBNAIL', '127', '150', 'images/media/2019/10/thumbnail1570778968YZyoU11507.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('106', '93', 'ACTUAL', '301', '770', 'images/media/2019/10/RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('107', '93', 'THUMBNAIL', '59', '150', 'images/media/2019/10/thumbnail1570787475RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('108', '93', 'MEDIUM', '156', '400', 'images/media/2019/10/medium1570787476RLshK11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('109', '94', 'ACTUAL', '211', '570', 'images/media/2019/10/pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('110', '94', 'THUMBNAIL', '56', '150', 'images/media/2019/10/thumbnail1570787731pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('111', '94', 'MEDIUM', '148', '400', 'images/media/2019/10/medium1570787731pTZdI11309.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('112', '95', 'ACTUAL', '451', '570', 'images/media/2019/10/2t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('113', '95', 'THUMBNAIL', '119', '150', 'images/media/2019/10/thumbnail15707877532t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('114', '95', 'MEDIUM', '316', '400', 'images/media/2019/10/medium15707877542t7BU11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('115', '96', 'ACTUAL', '211', '270', 'images/media/2019/10/O0cLp11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('116', '96', 'THUMBNAIL', '117', '150', 'images/media/2019/10/thumbnail1570787792O0cLp11909.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('117', '97', 'ACTUAL', '298', '568', 'images/media/2019/10/ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('118', '97', 'THUMBNAIL', '79', '150', 'images/media/2019/10/thumbnail1570787936ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('119', '97', 'MEDIUM', '210', '400', 'images/media/2019/10/medium1570787936ncXhn11709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('120', '98', 'ACTUAL', '452', '569', 'images/media/2019/10/3876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('121', '98', 'THUMBNAIL', '119', '150', 'images/media/2019/10/thumbnail15707880203876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('122', '98', 'MEDIUM', '318', '400', 'images/media/2019/10/medium15707880213876V11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('123', '99', 'ACTUAL', '451', '271', 'images/media/2019/10/80IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('124', '99', 'THUMBNAIL', '150', '90', 'images/media/2019/10/thumbnail157078802180IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('125', '99', 'MEDIUM', '400', '240', 'images/media/2019/10/medium157078802180IGj11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('126', '100', 'ACTUAL', '493', '370', 'images/media/2019/10/ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('127', '100', 'THUMBNAIL', '150', '113', 'images/media/2019/10/thumbnail1570788170ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('128', '100', 'MEDIUM', '400', '300', 'images/media/2019/10/medium1570788171ueeqM11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('129', '101', 'ACTUAL', '230', '370', 'images/media/2019/10/UrgVW11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('130', '101', 'THUMBNAIL', '93', '150', 'images/media/2019/10/thumbnail1570788171UrgVW11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('131', '102', 'ACTUAL', '230', '370', 'images/media/2019/10/a18kN11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('132', '102', 'THUMBNAIL', '93', '150', 'images/media/2019/10/thumbnail1570788301a18kN11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('133', '103', 'ACTUAL', '493', '370', 'images/media/2019/10/qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('134', '103', 'THUMBNAIL', '150', '113', 'images/media/2019/10/thumbnail1570788302qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('135', '103', 'MEDIUM', '400', '300', 'images/media/2019/10/medium1570788302qQM0R11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('136', '104', 'ACTUAL', '259', '770', 'images/media/2019/10/VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('137', '104', 'THUMBNAIL', '50', '150', 'images/media/2019/10/thumbnail1570788382VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('138', '104', 'MEDIUM', '135', '400', 'images/media/2019/10/medium1570788382VrhhT11510.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('139', '105', 'ACTUAL', '546', '372', 'images/media/2019/10/gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('140', '105', 'THUMBNAIL', '150', '102', 'images/media/2019/10/thumbnail1570788383gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('141', '105', 'MEDIUM', '400', '273', 'images/media/2019/10/medium1570788383gSkR011310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('142', '106', 'ACTUAL', '430', '1599', 'images/media/2019/10/DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('143', '106', 'THUMBNAIL', '40', '150', 'images/media/2019/10/thumbnail1570789393DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('144', '106', 'MEDIUM', '108', '400', 'images/media/2019/10/medium1570789394DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('145', '106', 'LARGE', '242', '900', 'images/media/2019/10/large1570789394DXoxt11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('146', '107', 'ACTUAL', '236', '1169', 'images/media/2019/10/N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('147', '107', 'THUMBNAIL', '30', '150', 'images/media/2019/10/thumbnail1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('148', '107', 'MEDIUM', '81', '400', 'images/media/2019/10/medium1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('149', '107', 'LARGE', '182', '900', 'images/media/2019/10/large1570789395N4WSZ11310.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('150', '108', 'ACTUAL', '421', '1170', 'images/media/2019/10/z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('151', '108', 'THUMBNAIL', '54', '150', 'images/media/2019/10/thumbnail1570789643z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('152', '108', 'MEDIUM', '144', '400', 'images/media/2019/10/medium1570789643z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('153', '108', 'LARGE', '324', '900', 'images/media/2019/10/large1570789644z9MLR11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('154', '109', 'ACTUAL', '418', '885', 'images/media/2019/10/YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('155', '109', 'THUMBNAIL', '71', '150', 'images/media/2019/10/thumbnail1570789935YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('156', '109', 'MEDIUM', '189', '400', 'images/media/2019/10/medium1570789935YNVyV11410.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('157', '110', 'ACTUAL', '387', '770', 'images/media/2019/10/YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('158', '110', 'THUMBNAIL', '75', '150', 'images/media/2019/10/thumbnail1570790072YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('159', '110', 'MEDIUM', '201', '400', 'images/media/2019/10/medium1570790072YinE411810.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('160', '111', 'ACTUAL', '421', '1600', 'images/media/2019/10/97VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('161', '111', 'THUMBNAIL', '39', '150', 'images/media/2019/10/thumbnail157079031897VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('162', '111', 'MEDIUM', '105', '400', 'images/media/2019/10/medium157079031997VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('163', '111', 'LARGE', '237', '900', 'images/media/2019/10/large157079031997VNC11210.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('168', '114', 'ACTUAL', '179', '370', 'images/media/2019/10/zZZ2n11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('169', '114', 'THUMBNAIL', '73', '150', 'images/media/2019/10/thumbnail1570790472zZZ2n11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('170', '115', 'ACTUAL', '211', '370', 'images/media/2019/10/vMNsa11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('171', '115', 'THUMBNAIL', '86', '150', 'images/media/2019/10/thumbnail1570790553vMNsa11710.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('172', '116', 'ACTUAL', '208', '465', 'images/media/2019/10/qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('173', '116', 'THUMBNAIL', '67', '150', 'images/media/2019/10/thumbnail1570790554qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('174', '116', 'MEDIUM', '179', '400', 'images/media/2019/10/medium1570790554qujIz11610.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('176', '118', 'ACTUAL', '20', '30', 'images/media/2019/10/PJG0C11511.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('177', '119', 'ACTUAL', '20', '30', 'images/media/2019/10/SKOMJ11512.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('178', '120', 'ACTUAL', '20', '30', 'images/media/2019/10/newsletter.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('179', '121', 'ACTUAL', '101', '151', 'images/media/2020/12/dhtTi17106.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('180', '121', 'THUMBNAIL', '100', '150', 'images/media/2020/12/thumbnail1608187477dhtTi17106.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('181', '122', 'ACTUAL', '48', '48', 'images/media/2020/12/Am3r017407.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('185', '124', 'ACTUAL', '232', '207', 'images/media/2020/12/FfYsX17407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('186', '124', 'THUMBNAIL', '150', '134', 'images/media/2020/12/thumbnail1608190905FfYsX17407.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('187', '125', 'ACTUAL', '252', '212', 'images/media/2020/12/YbeHn17607.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('188', '125', 'THUMBNAIL', '150', '126', 'images/media/2020/12/thumbnail1608190912YbeHn17607.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('189', '126', 'ACTUAL', '252', '212', 'images/media/2020/12/tl3ph17707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('190', '126', 'THUMBNAIL', '150', '126', 'images/media/2020/12/thumbnail1608190916tl3ph17707.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('192', '128', 'ACTUAL', '48', '48', 'images/media/2020/12/DHR9y17807.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('193', '129', 'ACTUAL', '64', '64', 'images/media/2020/12/7la9C17607.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('194', '130', 'ACTUAL', '500', '500', 'images/media/2020/12/pwBPh17509.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('195', '130', 'THUMBNAIL', '150', '150', 'images/media/2020/12/thumbnail1608195671pwBPh17509.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('196', '130', 'MEDIUM', '400', '400', 'images/media/2020/12/medium1608195671pwBPh17509.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('197', '131', 'ACTUAL', '480', '480', 'images/media/2020/12/KvbvT17709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('198', '131', 'THUMBNAIL', '150', '150', 'images/media/2020/12/thumbnail1608195995KvbvT17709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('199', '131', 'MEDIUM', '400', '400', 'images/media/2020/12/medium1608195995KvbvT17709.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('205', '134', 'ACTUAL', '69', '100', 'images/media/2020/12/G79LA17209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('206', '135', 'ACTUAL', '480', '480', 'images/media/2020/12/ADXfo17110.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('207', '135', 'THUMBNAIL', '150', '150', 'images/media/2020/12/thumbnail1608201360ADXfo17110.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('208', '135', 'MEDIUM', '400', '400', 'images/media/2020/12/medium1608201361ADXfo17110.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('209', '136', 'ACTUAL', '67', '206', 'images/media/2020/12/dH8yI17212.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('210', '136', 'THUMBNAIL', '49', '150', 'images/media/2020/12/thumbnail1608207779dH8yI17212.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('211', '137', 'ACTUAL', '100', '160', 'images/media/2020/12/b98GP17112.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('212', '137', 'THUMBNAIL', '94', '150', 'images/media/2020/12/thumbnail1608208011b98GP17112.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('213', '138', 'ACTUAL', '73', '101', 'images/media/2020/12/DFs9717112.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('214', '139', 'ACTUAL', '110', '175', 'images/media/2020/12/DKjUV17812.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('215', '139', 'THUMBNAIL', '94', '150', 'images/media/2020/12/thumbnail1608208357DKjUV17812.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('216', '140', 'ACTUAL', '480', '480', 'images/media/2020/12/lpOD517312.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('217', '140', 'THUMBNAIL', '150', '150', 'images/media/2020/12/thumbnail1608209421lpOD517312.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('218', '140', 'MEDIUM', '400', '400', 'images/media/2020/12/medium1608209421lpOD517312.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('219', '141', 'ACTUAL', '480', '480', 'images/media/2020/12/OpAsw17312.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('220', '141', 'THUMBNAIL', '150', '150', 'images/media/2020/12/thumbnail1608209429OpAsw17312.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('221', '141', 'MEDIUM', '400', '400', 'images/media/2020/12/medium1608209429OpAsw17312.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('222', '142', 'ACTUAL', '167', '301', 'images/media/2020/12/U8phy18909.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('223', '142', 'THUMBNAIL', '83', '150', 'images/media/2020/12/thumbnail1608284096U8phy18909.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('224', '143', 'ACTUAL', '1437', '1200', 'images/media/2020/12/fkw5818209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('225', '143', 'THUMBNAIL', '150', '125', 'images/media/2020/12/thumbnail1608284165fkw5818209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('226', '143', 'MEDIUM', '400', '334', 'images/media/2020/12/medium1608284165fkw5818209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('227', '143', 'LARGE', '900', '752', 'images/media/2020/12/large1608284166fkw5818209.png', '', '2020-12-18 09:36:06');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('228', '144', 'ACTUAL', '400', '400', 'images/media/2020/12/NfJl618209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('229', '144', 'THUMBNAIL', '150', '150', 'images/media/2020/12/thumbnail1608284249NfJl618209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('230', '144', 'MEDIUM', '400', '400', 'images/media/2020/12/medium1608284249NfJl618209.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('231', '145', 'ACTUAL', '387', '770', 'images/media/2020/12/VE04X18611.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('232', '145', 'THUMBNAIL', '75', '150', 'images/media/2020/12/thumbnail1608290663VE04X18611.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('233', '145', 'MEDIUM', '201', '400', 'images/media/2020/12/medium1608290663VE04X18611.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('234', '146', 'ACTUAL', '179', '370', 'images/media/2020/12/KnNvm18911.jpg', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('235', '147', 'ACTUAL', '943', '2048', 'images/media/2020/12/vyrMF18202.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('236', '147', 'THUMBNAIL', '69', '150', 'images/media/2020/12/thumbnail1608301076vyrMF18202.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('237', '147', 'MEDIUM', '184', '400', 'images/media/2020/12/medium1608301077vyrMF18202.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('238', '147', 'LARGE', '414', '900', 'images/media/2020/12/large1608301077vyrMF18202.png', '', '2020-12-18 02:17:57');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('239', '148', 'ACTUAL', '280', '499', 'images/media/2020/12/GxGeT21609.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('240', '148', 'THUMBNAIL', '84', '150', 'images/media/2020/12/thumbnail1608543275GxGeT21609.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('241', '148', 'MEDIUM', '224', '400', 'images/media/2020/12/medium1608543275GxGeT21609.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('242', '149', 'ACTUAL', '67', '91', 'images/media/2020/12/sdGJe21709.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('243', '150', 'ACTUAL', '151', '151', 'images/media/2020/12/tbUmT21109.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('244', '150', 'THUMBNAIL', '150', '150', 'images/media/2020/12/thumbnail1608544315tbUmT21109.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('245', '151', 'ACTUAL', '341', '339', 'images/media/2020/12/9JCrT21702.png', '', '');


INSERT INTO image_categories (`id`, `image_id`, `image_type`, `height`, `width`, `path`, `created_at`, `updated_at`); VALUES ('246', '151', 'THUMBNAIL', '150', '149', 'images/media/2020/12/thumbnail16085605689JCrT21702.png', '', '');


TRUNCATE images; INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('3', 'XUF1110211.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('4', '0S9Uj10711.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('5', '49YbL10411.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('83', 'JqYfZ11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('84', '6Q4Qy11507.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('85', 'jOVnc11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('86', 'Ake4A11107.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('89', 'nDQtA11407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('90', 'ueyod11407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('91', 'xD6MF11207.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('92', 'YZyoU11507.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('93', 'RLshK11309.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('94', 'pTZdI11309.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('95', '2t7BU11909.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('96', 'O0cLp11909.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('97', 'ncXhn11709.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('98', '3876V11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('99', '80IGj11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('100', 'ueeqM11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('101', 'UrgVW11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('102', 'a18kN11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('103', 'qQM0R11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('104', 'VrhhT11510.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('105', 'gSkR011310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('106', 'DXoxt11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('107', 'N4WSZ11310.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('108', 'z9MLR11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('109', 'YNVyV11410.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('110', 'YinE411810.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('111', '97VNC11210.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('114', 'zZZ2n11710.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('115', 'vMNsa11710.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('116', 'qujIz11610.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('118', 'PJG0C11511.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('119', 'SKOMJ11512.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('120', 'newsletter.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('121', 'dhtTi17106.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('122', 'Am3r017407.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('124', 'FfYsX17407.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('125', 'YbeHn17607.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('126', 'tl3ph17707.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('128', 'DHR9y17807.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('129', '7la9C17607.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('130', 'pwBPh17509.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('131', 'KvbvT17709.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('134', 'G79LA17209.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('135', 'ADXfo17110.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('136', 'dH8yI17212.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('137', 'b98GP17112.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('138', 'DFs9717112.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('139', 'DKjUV17812.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('140', 'lpOD517312.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('141', 'OpAsw17312.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('142', 'U8phy18909.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('143', 'fkw5818209.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('144', 'NfJl618209.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('145', 'VE04X18611.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('146', 'KnNvm18911.jpg', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('147', 'vyrMF18202.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('148', 'GxGeT21609.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('149', 'sdGJe21709.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('150', 'tbUmT21109.png', '1', '', '', '');


INSERT INTO images (`id`, `name`, `user_id`, `deleted_at`, `created_at`, `updated_at`); VALUES ('151', '9JCrT21702.png', '1', '', '', '');


TRUNCATE inventory; INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('1', '1', '0', '', '10', '1', '320.00', 'in', '2020-12-17 09:17:57', '2020-12-17 14:17:57');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12322', '1', '0', '', '5', '1', '952.00', 'in', '2020-12-17 11:50:12', '2020-12-17 16:50:12');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12323', '1', '0', '', '10', '2', '259.00', 'in', '2020-12-17 01:02:29', '2020-12-17 18:02:29');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12324', '0', '1608287341', '', '2', '1', '0.00', 'out', '2020-12-18 15:29:01', '2020-12-18 15:29:01');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12325', '0', '1608287939', '', '1', '1', '0.00', 'out', '2020-12-18 15:38:59', '2020-12-18 15:38:59');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12326', '1', '0', '', '2', '2', '50.00', 'in', '2020-12-18 10:45:56', '2020-12-18 15:45:56');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12327', '1', '0', '', '100', '2', '100.00', 'in', '2020-12-18 10:48:57', '2020-12-18 15:48:57');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12328', '1', '0', '', '100', '2', '100.00', 'in', '2020-12-18 10:50:18', '2020-12-18 15:50:18');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12329', '1', '0', '', '100', '1', '1000.00', 'in', '2020-12-18 10:56:22', '2020-12-18 15:56:22');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12330', '1', '0', '', '100', '1', '1000.00', 'in', '2020-12-18 10:56:39', '2020-12-18 15:56:39');


INSERT INTO inventory (`inventory_ref_id`, `admin_id`, `added_date`, `reference_code`, `stock`, `products_id`, `purchase_price`, `stock_type`, `created_at`, `updated_at`); VALUES ('12331', '0', '1608553936', '', '1', '2', '0.00', 'out', '2020-12-21 17:32:16', '2020-12-21 17:32:16');


TRUNCATE inventory_detail; INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('1', '1', '1');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12322', '1', '2');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12323', '2', '3');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12324', '1', '1');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12325', '1', '1');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12326', '2', '3');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12326', '2', '5');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12326', '2', '8');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12327', '2', '3');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12327', '2', '5');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12327', '2', '7');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12328', '2', '3');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12328', '2', '6');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12328', '2', '7');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12329', '1', '2');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12330', '1', '1');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12331', '2', '5');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12331', '2', '3');


INSERT INTO inventory_detail (`inventory_ref_id`, `products_id`, `attribute_id`); VALUES ('12331', '2', '7');


TRUNCATE label_value; INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1297', 'Home', '1', '1031');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1298', 'Menu', '1', '1030');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1299', 'Clear', '1', '1029');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1300', 'Apply', '1', '1028');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1301', 'Close', '1', '1027');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1302', 'Price Range', '1', '1026');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1303', 'Filters', '1', '1025');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1304', 'My Wish List', '1', '1024');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1305', 'Log Out', '1', '1023');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1306', 'Please login or create an account for free', '1', '1022');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1307', 'login & Register', '1', '1021');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1308', 'Save Address', '1', '1020');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1309', 'State', '1', '1018');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1310', 'Update Address', '1', '1019');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1311', 'Post code', '1', '1017');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1312', 'City', '1', '1016');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1313', 'Zone', '1', '1015');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1314', 'other', '1', '1014');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1315', 'Country', '1', '1013');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1316', 'Shipping Address', '1', '1012');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1317', 'Proceed', '1', '1011');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1318', 'Remove', '1', '1010');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1319', 'by', '1', '1008');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1320', 'View', '1', '1009');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1321', 'Quantity', '1', '1007');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1322', 'Price', '1', '1006');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1323', 'continue shopping', '1', '1005');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1324', 'Your cart is empty', '1', '1004');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1325', 'My Cart', '1', '1003');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1326', 'Continue', '1', '1002');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1327', 'Error: invalid cvc number!', '1', '1001');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1328', 'Error: invalid expiry date!', '1', '1000');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1329', 'Error: invalid card number!', '1', '999');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1330', 'Expiration', '1', '998');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1331', 'Expiration Date', '1', '997');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1332', 'Card Number', '1', '996');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1333', 'Payment', '1', '995');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1334', 'Order Notes', '1', '994');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1335', 'Shipping Cost', '1', '993');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1336', 'Tax', '1', '992');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1337', 'Products Price', '1', '991');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1338', 'SubTotal', '1', '990');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1339', 'Products', '1', '989');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1340', 'Shipping Method', '1', '988');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1341', 'Billing Address', '1', '987');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1342', 'Order', '1', '986');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1343', 'Next', '1', '985');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1344', 'Same as Shipping Address', '1', '984');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1345', 'Billing Info', '1', '981');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1346', 'Address', '1', '982');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1347', 'Phone', '1', '983');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1348', 'Already Memeber?', '1', '980');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1349', 'Last Name', '1', '979');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1350', 'First Name', '1', '978');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1351', 'Create an Account', '1', '977');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1352', 'Add new Address', '1', '976');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1353', 'Please add your new shipping address for the futher processing of the your order', '1', '975');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1354', 'Order Status', '1', '969');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1355', 'Orders ID', '1', '970');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1356', 'Product Price', '1', '971');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1357', 'No. of Products', '1', '972');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1358', 'Date', '1', '973');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1359', 'Customer Address', '1', '974');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1360', 'Customer Orders', '1', '968');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1361', 'Change Password', '1', '967');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1362', 'New Password', '1', '966');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1363', 'Current Password', '1', '965');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1364', 'Update', '1', '964');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1365', 'Date of Birth', '1', '963');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1366', 'Mobile', '1', '962');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1367', 'My Account', '1', '961');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1368', 'Likes', '1', '960');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1369', 'Newest', '1', '959');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1370', 'Top Seller', '1', '958');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1371', 'Special', '1', '957');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1372', 'Most Liked', '1', '956');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1373', 'Cancel', '1', '955');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1374', 'Sort Products', '1', '954');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1375', 'Special Products', '1', '953');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1376', 'Price : low - high', '1', '952');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1377', 'Price : high - low', '1', '951');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1378', 'Z - A', '1', '950');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1379', 'A - Z', '1', '949');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1380', 'All', '1', '948');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1381', 'Explore More', '1', '947');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1382', 'Note to the buyer', '1', '946');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1383', 'Coupon', '1', '945');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1384', 'coupon code', '1', '944');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1385', 'Coupon Amount', '1', '943');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1386', 'Coupon Code', '1', '942');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1387', 'Food Categories', '1', '941');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1388', 'Recipe of Day', '1', '940');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1389', 'Top Dishes', '1', '939');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1390', 'Skip', '1', '938');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1391', 'Term and Services', '1', '937');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1392', 'Privacy Policy', '1', '936');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1393', 'Refund Policy', '1', '935');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1394', 'Newest', '1', '934');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1395', 'OUT OF STOCK', '1', '933');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1396', 'Select Language', '1', '932');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1397', 'Reset', '1', '931');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1398', 'Shop', '1', '930');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1399', 'Settings', '1', '929');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1400', 'Enter keyword', '1', '928');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1401', 'News', '1', '927');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1402', 'Top Sellers', '1', '926');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1403', 'Go Back', '1', '925');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1404', 'Word Press Post Detail', '1', '924');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1405', 'Explore', '1', '923');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1406', 'Continue Adding', '1', '922');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1407', 'Your wish List is empty', '1', '921');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1408', 'Favourite', '1', '920');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1409', 'Continue Shopping', '1', '919');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1410', 'My Orders', '1', '918');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1411', 'Thank you for shopping with us.', '1', '917');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1412', 'Thank You', '1', '916');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1413', 'Shipping method', '1', '915');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1414', 'Brands', '1', '914');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1415', 'Manufacturers', '1', '913');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1416', 'Search', '1', '912');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1417', 'Reset Filters', '1', '911');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1418', 'No Products Found', '1', '910');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1419', 'OFF', '1', '909');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1420', 'Techincal details', '1', '908');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1421', 'Product Description', '1', '907');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1422', 'ADD TO CART', '1', '906');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1423', 'Add to Cart', '1', '905');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1424', 'In Stock', '1', '904');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1425', 'Out of Stock', '1', '903');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1426', 'New', '1', '902');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1427', 'Product Details', '1', '901');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1428', 'Shipping', '1', '900');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1429', 'Sub Total', '1', '899');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1430', 'Total', '1', '898');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1431', 'Price Detail', '1', '897');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1432', 'Order Detail', '1', '896');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1433', 'Got It!', '1', '895');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1434', 'Skip Intro', '1', '894');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1435', 'Intro', '1', '893');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1436', 'REMOVE', '1', '892');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1437', 'Deals', '1', '891');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1438', 'All Manufacturers', '1', '890');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1439', 'Most Liked', '1', '889');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1440', 'Special Deals', '1', '888');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1441', 'Top Seller', '1', '887');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1442', 'Products are available.', '1', '886');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1443', 'Recently Viewed', '1', '885');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1444', 'Please connect to the internet', '1', '884');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1445', 'Contact Us', '1', '881');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1446', 'Name', '1', '882');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1447', 'Your Message', '1', '883');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1448', 'Manufacturers', '1', '880');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1449', 'About Us', '1', '879');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1450', 'Send', '1', '878');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1451', 'Forgot Password', '1', '877');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1452', 'Register', '1', '876');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1453', 'Password', '1', '875');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1454', 'Email', '1', '874');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1455', 'or', '1', '873');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1456', 'Login with', '1', '872');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1457', 'Creating an account means you\'re okay with shopify\'s Terms of Service, Privacy Policy', '1', '2');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1458', 'I\'ve forgotten my password?', '1', '1');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1459', '', '1', '');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1462', 'Creating an account means you’re okay with our', '1', '1033');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1465', 'Login', '1', '1034');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1468', 'Turn on/off Local Notifications', '1', '1035');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1471', 'Turn on/off Notifications', '1', '1036');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1474', 'Change Language', '1', '1037');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1477', 'Official Website', '1', '1038');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1480', 'Rate Us', '1', '1039');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1483', 'Share', '1', '1040');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1486', 'Edit Profile', '1', '1041');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1489', 'A percentage discount for the entire cart', '1', '1042');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1492', 'A fixed total discount for the entire cart', '1', '1043');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1495', 'A fixed total discount for selected products only', '1', '1044');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1498', 'A percentage discount for selected products only', '1', '1045');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1501', 'Network Connected Reloading Data', '1', '1047');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1503', 'Sort by', '1', '1048');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1505', 'Flash Sale', '1', '1049');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1507', 'ok', '1', '1050');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1509', 'Number', '1', '1051');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1511', 'Expire Month', '1', '1052');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1513', 'Expire Year', '1', '1053');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1515', 'Payment Method', '1', '1054');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1517', 'Status', '1', '1055');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1519', 'And', '1', '1056');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1520', 'نسيت كلمة المرور الخاصة بي؟', '4', '1');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1521', 'إن إنشاء حساب يعني موافقتك على شروط الخدمة وسياسة الخصوصية', '4', '2');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1522', 'تسجيل الدخول مع', '4', '872');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1523', 'أو', '4', '873');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1524', 'البريد الإلكتروني', '4', '874');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1525', 'كلمه السر', '4', '875');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1526', 'تسجيل', '4', '876');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1527', 'هل نسيت كلمة المرور', '4', '877');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1528', 'إرسال', '4', '878');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1529', 'معلومات عنا', '4', '879');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1530', 'التصنيفات', '4', '880');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1531', 'اتصل بنا', '4', '881');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1532', 'اسم', '4', '882');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1533', 'رسالتك', '4', '883');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1534', 'يرجى الاتصال بالإنترنت', '4', '884');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1535', 'شوهدت مؤخرا', '4', '885');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1536', 'المنتجات المتاحة.', '4', '886');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1537', 'أعلى بائع', '4', '887');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1538', 'صفقة خاصة', '4', '888');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1539', 'الأكثر إعجابا', '4', '889');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1540', 'جميع الفئات', '4', '890');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1541', 'صفقات', '4', '891');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1542', 'إزالة', '4', '892');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1543', 'مقدمة', '4', '893');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1544', 'تخطي المقدمة', '4', '894');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1545', 'فهمتك!', '4', '895');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1546', 'تفاصيل الطلب', '4', '896');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1547', 'سعر التفاصيل', '4', '897');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1548', 'مجموع', '4', '898');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1549', 'المجموع الفرعي', '4', '899');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1550', 'الشحن', '4', '900');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1551', 'تفاصيل المنتج', '4', '901');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1552', 'جديد', '4', '902');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1553', 'إنتهى من المخزن', '4', '903');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1554', 'في المخزن', '4', '904');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1555', 'أضف إلى السلة', '4', '905');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1556', 'أضف إلى السلة', '4', '906');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1557', 'وصف المنتج', '4', '907');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1558', 'تفاصيل تقنية', '4', '908');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1559', 'إيقاف', '4', '909');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1560', 'لا توجد منتجات', '4', '910');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1561', 'إعادة تعيين المرشحات', '4', '911');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1562', 'بحث', '4', '912');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1563', 'الفئات الرئيسية', '4', '913');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1564', 'الفئات الفرعية', '4', '914');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1565', 'طريقة الشحن', '4', '915');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1566', 'شكرا جزيلا', '4', '916');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1567', 'شكرا للتسوق معنا.', '4', '917');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1568', 'طلباتي', '4', '918');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1569', 'مواصلة التسوق', '4', '919');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1570', '', '4', '');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1571', 'مفضل', '4', '920');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1572', 'قائمة رغباتك فارغة', '4', '921');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1573', 'متابعة الإضافة', '4', '922');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1574', 'يكتشف', '4', '923');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1575', 'وورد بوست التفاصيل', '4', '924');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1576', 'عد', '4', '925');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1577', 'أفضل البائعين', '4', '926');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1578', 'أخبار', '4', '927');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1579', 'أدخل الكلمة المفتاحية', '4', '928');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1580', 'الإعدادات', '4', '929');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1581', 'متجر', '4', '930');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1582', 'إعادة تعيين', '4', '931');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1583', 'اختار اللغة', '4', '932');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1584', 'إنتهى من المخزن', '4', '933');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1585', 'الأحدث', '4', '934');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1586', 'سياسة الاسترجاع', '4', '935');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1587', 'سياسة خاصة', '4', '936');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1588', 'مصطلح والخدمات', '4', '937');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1589', 'تخطى', '4', '938');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1590', 'أطباق الأعلى', '4', '939');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1591', 'وصفة اليوم', '4', '940');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1592', 'فئات الغذاء', '4', '941');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1593', 'رمز الكوبون', '4', '942');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1594', 'مبلغ القسيمة', '4', '943');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1595', 'رمز الكوبون', '4', '944');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1596', 'كوبون', '4', '945');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1597', 'ملاحظة للمشتري', '4', '946');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1598', 'استكشاف المزيد', '4', '947');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1599', 'الكل', '4', '948');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1600', 'أ - ي', '4', '949');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1601', 'ي - أ', '4', '950');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1602', 'السعر مرتفع منخفض', '4', '951');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1603', 'سعر منخفض مرتفع', '4', '952');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1604', 'المنتجات الخاصة', '4', '953');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1605', 'فرز المنتجات', '4', '954');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1606', 'إلغاء', '4', '955');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1607', 'الأكثر إعجابا', '4', '956');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1608', 'خاص', '4', '957');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1609', 'أعلى بائع', '4', '958');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1610', 'الأحدث', '4', '959');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1611', 'الإعجابات', '4', '960');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1612', 'حسابي', '4', '961');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1613', 'التليفون المحمول', '4', '962');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1614', 'تاريخ الولادة', '4', '963');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1615', 'تحديث', '4', '964');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1616', 'كلمة المرور الحالية', '4', '965');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1617', 'كلمة سر جديدة', '4', '966');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1618', 'تغيير كلمة المرور', '4', '967');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1619', 'طلبات العملاء', '4', '968');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1620', 'حالة الطلب', '4', '969');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1621', 'معرف الطلبات', '4', '970');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1622', 'سعر المنتج', '4', '971');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1623', 'عدد المنتجات', '4', '972');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1624', 'تاريخ', '4', '973');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1625', 'عنوان العميل', '4', '974');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1626', 'يرجى إضافة عنوان الشحن الجديد لمزيد من المعالجة لطلبك', '4', '975');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1627', 'إضافة عنوان جديد', '4', '976');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1628', 'انشئ حساب', '4', '977');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1629', 'الاسم الاول', '4', '978');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1630', 'الكنية', '4', '979');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1631', 'هل أنت عضو بالفعل؟', '4', '980');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1632', 'معلومات الفواتير', '4', '981');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1633', 'عنوان', '4', '982');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1634', 'هاتف', '4', '983');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1635', 'نفس عنوان الشحن', '4', '984');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1636', 'التالى', '4', '985');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1637', 'طلب', '4', '986');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1638', 'عنوان وصول الفواتير', '4', '987');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1639', 'طريقة الشحن', '4', '988');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1640', 'منتجات', '4', '989');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1641', 'حاصل الجمع', '4', '990');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1642', 'سعر المنتجات', '4', '991');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1643', 'ضريبة', '4', '992');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1644', 'تكلفة الشحن', '4', '993');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1645', 'ترتيب ملاحظات', '4', '994');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1646', 'دفع', '4', '995');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1647', 'رقم البطاقة', '4', '996');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1648', 'تاريخ الإنتهاء', '4', '997');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1649', 'انتهاء الصلاحية', '4', '998');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1650', 'خطأ: رقم البطاقة غير صالح!', '4', '999');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1651', 'خطأ: تاريخ انتهاء الصلاحية غير صحيح!', '4', '1000');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1652', 'خطأ: رقم cvc غير صالح!', '4', '1001');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1653', 'استمر', '4', '1002');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1654', 'سلتي', '4', '1003');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1655', 'عربة التسوق فارغة', '4', '1004');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1656', 'مواصلة التسوق', '4', '1005');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1657', 'السعر', '4', '1006');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1658', 'كمية', '4', '1007');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1659', 'بواسطة', '4', '1008');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1660', 'رأي', '4', '1009');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1661', 'إزالة', '4', '1010');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1662', 'تقدم', '4', '1011');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1663', 'عنوان الشحن', '4', '1012');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1664', 'بلد', '4', '1013');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1665', 'آخر', '4', '1014');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1666', 'منطقة', '4', '1015');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1667', 'مدينة', '4', '1016');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1668', 'الرمز البريدي', '4', '1017');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1669', 'حالة', '4', '1018');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1670', 'تحديث العنوان', '4', '1019');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1671', 'حفظ العنوان', '4', '1020');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1672', 'دخولتسجيل', '4', '1021');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1673', 'يرجى تسجيل الدخول أو إنشاء حساب مجانا', '4', '1022');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1674', 'تسجيل خروج', '4', '1023');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1675', 'قائمة امنياتي', '4', '1024');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1676', 'مرشحات', '4', '1025');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1677', 'نطاق السعر', '4', '1026');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1678', 'قريب', '4', '1027');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1679', 'تطبيق', '4', '1028');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1680', 'واضح', '4', '1029');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1681', 'قائمة طعام', '4', '1030');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1682', 'الصفحة الرئيسية', '4', '1031');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1683', 'إن إنشاء حساب يعني أنك بخير من خلال موقعنا', '4', '1033');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1684', 'تسجيل الدخول', '4', '1034');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1685', 'تشغيل / إيقاف الإشعارات', '4', '1035');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1686', 'تشغيل / إيقاف الإشعارات', '4', '1036');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1687', 'تغيير اللغة', '4', '1037');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1688', 'الموقع الرسمي', '4', '1038');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1689', 'قيمنا', '4', '1039');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1690', 'شارك', '4', '1040');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1691', 'تعديل الملف الشخصي', '4', '1041');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1692', 'خصم النسبة المئوية للسلة بأكملها', '4', '1042');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1693', 'خصم إجمالي ثابت للعربة بأكملها', '4', '1043');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1694', 'خصم إجمالي ثابت للمنتجات المحددة فقط', '4', '1044');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1695', 'خصم النسبة المئوية للمنتجات المختارة فقط', '4', '1045');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1696', 'شبكة متصلة إعادة تحميل البيانات', '4', '1047');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1697', 'صنف حسب', '4', '1048');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1698', 'بيع مفاجئ', '4', '1049');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1699', 'حسنا', '4', '1050');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1700', 'رقم', '4', '1051');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1701', 'انتهاء الشهر', '4', '1052');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1702', 'انتهاء السنة', '4', '1053');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1703', 'طريقة الدفع او السداد', '4', '1054');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1704', 'الحالة', '4', '1055');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1705', 'و', '4', '1056');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1706', 'cccc', '1', '1057');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1707', 'cccc', '4', '1057');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1708', 'Shop More', '1', '1058');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1709', 'عربي', '4', '1058');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1710', 'Discount', '1', '1072');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1711', 'خصم', '4', '1072');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1712', 'Error in initialization, maybe PayPal isnt supported or something else', '1', '1073');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1713', 'خطأ في التهيئة ، ربما لا يتم دعم PayPal أو أي شيء آخر', '4', '1073');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1714', 'Alert', '1', '1074');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1715', 'إنذار', '4', '1074');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1716', 'Your Wishlist is Empty', '1', '1075');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1717', 'قائمة رغباتك فارغة', '4', '1075');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1718', 'Press heart icon on products to add them in wishlist', '1', '1076');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1719', 'اضغط على أيقونة القلب على المنتجات لإضافتها إلى قائمة الرغبات', '4', '1076');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1720', 'Wishlist', '1', '1077');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1721', 'قائمة الرغبات', '4', '1077');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1722', 'All Items', '1', '1078');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1723', 'كل الاشياء', '4', '1078');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1724', 'Account Info', '1', '1079');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1725', 'معلومات الحساب', '4', '1079');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1726', 'You Must Be Logged in to use this Feature!', '1', '1080');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1727', 'يجب عليك تسجيل الدخول لاستخدام هذه الميزة!', '4', '1080');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1728', 'Remove from Wishlist', '1', '1081');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1729', 'إزالة من قائمة الرغبات', '4', '1081');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1730', 'Sign Up', '1', '1082');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1731', 'سجل', '4', '1082');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1732', 'Reset Password', '1', '1083');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1733', 'إعادة تعيين كلمة المرور', '4', '1083');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1734', 'Invalid email or password', '1', '1084');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1735', 'البريد الإلكتروني أو كلمة السر خاطئة', '4', '1084');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1736', 'Recent Searches', '1', '1085');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1737', 'عمليات البحث الأخيرة', '4', '1085');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1738', 'Add to Wishlist', '1', '1086');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1739', 'أضف إلى قائمة الامنيات', '4', '1086');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1740', 'Discover Latest Trends', '1', '1087');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1741', 'اكتشف أحدث الاتجاهات', '4', '1087');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1742', 'Add To My Wishlist', '1', '1088');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1743', 'أضف إلى قائمة أمنياتي', '4', '1088');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1744', 'Start Shoping', '1', '1089');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1745', 'ابدأ التسوق', '4', '1089');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1746', 'A Smart Shopping Experience', '1', '1090');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1747', 'تجربة تسوق ذكية', '4', '1090');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1748', 'Addresses', '1', '1091');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1749', 'عناوين', '4', '1091');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1750', 'Account', '1', '1092');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1751', 'الحساب', '4', '1092');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1752', 'DETAILS', '1', '1093');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1753', 'تفاصيل', '4', '1093');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1754', 'Dark Mode', '1', '1094');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1755', 'الوضع الداكن', '4', '1094');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1756', 'Enter a description', '1', '1095');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1757', 'أدخل وصفًا', '4', '1095');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1758', 'Grocery Store', '1', '1096');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1759', 'بقالة', '4', '1096');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1760', 'Post Comment', '1', '1097');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1761', 'أضف تعليقا', '4', '1097');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1762', 'Rate and write a review', '1', '1098');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1763', 'تقييم وكتابة مراجعة', '4', '1098');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1764', 'Ratings & Reviews', '1', '1099');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1765', 'التقييمات والمراجعات', '4', '1099');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1766', 'Write a review', '1', '1100');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1767', 'أكتب مراجعة', '4', '1100');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1768', 'Your Rating', '1', '1101');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1769', 'تقييمك', '4', '1101');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1770', 'rating', '1', '1102');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1771', 'تقييم', '4', '1102');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1772', 'rating and review', '1', '1103');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1773', 'تصنيف ومراجعة', '4', '1103');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1774', 'Coupon Codes List', '1', '1104');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1775', 'قائمة رموز القسيمة', '4', '1104');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1776', 'Custom Orders', '1', '1105');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1777', 'أوامر مخصصة', '4', '1105');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1778', 'Ecommerce', '1', '1106');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1779', 'التجارة الإلكترونية', '4', '1106');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1780', 'Featured Products', '1', '1107');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1781', 'منتجات مميزة', '4', '1107');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1782', 'House Hold 1', '1', '1108');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1783', 'المنزل عقد 1', '4', '1108');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1784', 'Newest Products', '1', '1109');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1785', 'أحدث المنتجات', '4', '1109');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1786', 'On Sale Products', '1', '1110');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1787', 'المنتجات المعروضة للبيع', '4', '1110');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1788', 'Braintree', '1', '1111');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1789', 'برينتري', '4', '1111');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1790', 'Hyperpay', '1', '1112');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1791', 'Hyperpay', '4', '1112');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1792', 'Instamojo', '1', '1113');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1793', 'Instamojo', '4', '1113');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1794', 'PayTm', '1', '1114');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1795', 'PayTm', '4', '1114');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1796', 'Paypal', '1', '1115');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1797', 'باي بال', '4', '1115');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1798', 'Razor Pay', '1', '1116');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1799', 'الحلاقة الدفع', '4', '1116');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1800', 'Stripe', '1', '1117');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1801', 'شريط', '4', '1117');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1802', 'Me', '1', '1059');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1803', 'أنا', '4', '1059');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1804', 'View All', '1', '1060');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1805', 'عرض الكل', '4', '1060');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1806', 'Featured', '1', '1061');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1807', 'متميز', '4', '1061');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1808', 'Shop Now', '1', '1062');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1809', 'تسوق الآن', '4', '1062');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1810', 'New Arrivals', '1', '1063');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1811', 'الوافدون الجدد', '4', '1063');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1812', 'Sort', '1', '1064');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1813', 'فرز', '4', '1064');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1814', 'Help & Support', '1', '1065');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1815', 'ساعد لدعم', '4', '1065');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1816', 'Select Currency', '1', '1066');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1817', 'اختر العملة', '4', '1066');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1818', 'Your Price', '1', '1067');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1819', 'السعر الخاص', '4', '1067');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1820', 'Billing', '1', '1068');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1821', 'الفواتير', '4', '1068');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1822', 'Ship to a different address?', '1', '1069');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1823', 'هل تريد الشحن إلى عنوان مختلف؟', '4', '1069');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1824', 'Method', '1', '1070');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1825', 'طريقة', '4', '1070');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1826', 'Summary', '1', '1071');


INSERT INTO label_value (`label_value_id`, `label_value`, `language_id`, `label_id`); VALUES ('1827', 'ملخص', '4', '1071');


TRUNCATE labels; INSERT INTO labels (`label_id`, `label_name`); VALUES ('1', 'I\'ve forgotten my password?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('2', 'Creating an account means you’re okay with shopify\'s Terms of Service, Privacy Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('872', 'Login with');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('873', 'or');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('874', 'Email');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('875', 'Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('876', 'Register');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('877', 'Forgot Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('878', 'Send');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('879', 'About Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('880', 'Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('881', 'Contact Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('882', 'Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('883', 'Your Messsage');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('884', 'Please connect to the internet');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('885', 'Recently Viewed');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('886', 'Products are available.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('887', 'Top Seller');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('888', 'Special Deals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('889', 'Most Liked');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('890', 'All Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('891', 'Deals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('892', 'REMOVE');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('893', 'Intro');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('894', 'Skip Intro');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('895', 'Got It!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('896', 'Order Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('897', 'Price Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('898', 'Total');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('899', 'Sub Total');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('900', 'Shipping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('901', 'Product Details');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('902', 'New');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('903', 'Out of Stock');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('904', 'In Stock');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('905', 'Add to Cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('906', 'ADD TO CART');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('907', 'Product Description');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('908', 'Techincal details');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('909', 'OFF');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('910', 'No Products Found');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('911', 'Reset Filters');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('912', 'Search');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('913', 'Main Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('914', 'Sub Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('915', 'Shipping method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('916', 'Thank You');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('917', 'Thank you for shopping with us.');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('918', 'My Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('919', 'Continue Shopping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('920', 'Favourite');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('921', 'Your wish List is empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('922', 'Continue Adding');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('923', 'Explore');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('924', 'Word Press Post Detail');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('925', 'Go Back');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('926', 'Top Sellers');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('927', 'News');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('928', 'Enter keyword');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('929', 'Settings');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('930', 'Shop');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('931', 'Reset');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('932', 'Select Language');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('933', 'OUT OF STOCK');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('934', 'Newest');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('935', 'Refund Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('936', 'Privacy Policy');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('937', 'Term and Services');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('938', 'Skip');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('939', 'Top Dishes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('940', 'Recipe of Day');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('941', 'Food Categories');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('942', 'Coupon Code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('943', 'Coupon Amount');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('944', 'coupon code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('945', 'Coupon');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('946', 'Note to the buyer');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('947', 'Explore More');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('948', 'All');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('949', 'A - Z');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('950', 'Z - A');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('951', 'Price : high - low');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('952', 'Price : low - high');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('953', 'Special Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('954', 'Sort Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('955', 'Cancel');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('956', 'most liked');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('957', 'special');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('958', 'top seller');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('959', 'newest');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('960', 'Likes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('961', 'My Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('962', 'Mobile');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('963', 'Date of Birth');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('964', 'Update');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('965', 'Current Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('966', 'New Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('967', 'Change Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('968', 'Customer Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('969', 'Order Status');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('970', 'Orders ID');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('971', 'Product Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('972', 'No. of Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('973', 'Date');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('974', 'Customer Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('975', 'Please add your new shipping address for the futher processing of the your order');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('976', 'Add new Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('977', 'Create an Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('978', 'First Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('979', 'Last Name');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('980', 'Already Memeber?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('981', 'Billing Info');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('982', 'Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('983', 'Phone');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('984', 'Same as Shipping Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('985', 'Next');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('986', 'Order');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('987', 'Billing Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('988', 'Shipping Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('989', 'Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('990', 'SubTotal');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('991', 'Products Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('992', 'Tax');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('993', 'Shipping Cost');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('994', 'Order Notes');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('995', 'Payment');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('996', 'Card Number');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('997', 'Expiration Date');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('998', 'Expiration');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('999', 'Error: invalid card number!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1000', 'Error: invalid expiry date!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1001', 'Error: invalid cvc number!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1002', 'Continue');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1003', 'My Cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1004', 'Your cart is empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1005', 'continue shopping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1006', 'Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1007', 'Quantity');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1008', 'by');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1009', 'View');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1010', 'Remove');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1011', 'Proceed');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1012', 'Shipping Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1013', 'Country');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1014', 'other');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1015', 'Zone');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1016', 'City');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1017', 'Post code');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1018', 'State');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1019', 'Update Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1020', 'Save Address');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1021', 'Login & Register');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1022', 'Please login or create an account for free');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1023', 'Log Out');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1024', 'My Wish List');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1025', 'Filters');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1026', 'Price Range');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1027', 'Close');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1028', 'Apply');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1029', 'Clear');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1030', 'Menu');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1031', 'Home');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1033', 'Creating an account means you’re okay with our');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1034', 'Login');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1035', 'Turn on/off Local Notifications');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1036', 'Turn on/off Notifications');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1037', 'Change Language');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1038', 'Official Website');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1039', 'Rate Us');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1040', 'Share');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1041', 'Edit Profile');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1042', 'A percentage discount for the entire cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1043', 'A fixed total discount for the entire cart');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1044', 'A fixed total discount for selected products only');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1045', 'A percentage discount for selected products only');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1047', 'Network Connected Reloading Data');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1048', 'Sort by');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1049', 'Flash Sale');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1050', 'ok');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1051', 'Number');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1052', 'Expire Month');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1053', 'Expire Year');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1054', 'Payment Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1055', 'Status');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1056', 'And');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1057', 'cccc');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1058', 'Shop More');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1059', 'Me');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1060', 'View All');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1061', 'Featured');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1062', 'Shop Now');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1063', 'New Arrivals');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1064', 'Sort');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1065', 'Help & Support');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1066', 'Select Currency');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1067', 'Your Price');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1068', 'Billing');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1069', 'Ship to a different address?');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1070', 'Method');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1071', 'Summary');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1072', 'Discount');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1073', 'Error in initialization, maybe PayPal isnt supported or something else');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1074', 'Alert');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1075', 'Your Wishlist is Empty');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1076', 'Press heart icon on products to add them in wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1077', 'Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1078', 'All Items');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1079', 'Account Info');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1080', 'You Must Be Logged in to use this Feature!');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1081', 'Remove from Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1082', 'Sign Up');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1083', 'Reset Password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1084', 'Invalid email or password');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1085', 'Recent Searches');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1086', 'Add to Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1087', 'Discover Latest Trends');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1088', 'Add To My Wishlist');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1089', 'Start Shoping');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1090', 'A Smart Shopping Experience');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1091', 'Addresses');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1092', 'Account');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1093', 'DETAILS');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1094', 'Dark Mode');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1095', 'Enter a description');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1096', 'Grocery Store');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1097', 'Post Comment');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1098', 'Rate and write a review');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1099', 'Ratings & Reviews');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1100', 'Write a review');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1101', 'Your Rating');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1102', 'rating');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1103', 'rating and review');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1104', 'Coupon Codes List');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1105', 'Custom Orders');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1106', 'Ecommerce');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1107', 'Featured Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1108', 'House Hold 1');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1109', 'Newest Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1110', 'On Sale Products');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1111', 'Braintree');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1112', 'Hyperpay');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1113', 'Instamojo');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1114', 'PayTm');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1115', 'Paypal');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1116', 'Razor Pay');


INSERT INTO labels (`label_id`, `label_name`); VALUES ('1117', 'Stripe');


TRUNCATE languages; INSERT INTO languages (`languages_id`, `name`, `code`, `image`, `directory`, `sort_order`, `direction`, `status`, `is_default`); VALUES ('1', 'English', 'en', '118', '', '1', 'ltr', '1', '1');


TRUNCATE liked_products; INSERT INTO liked_products (`like_id`, `liked_products_id`, `liked_customers_id`, `date_liked`); VALUES ('1', '1', '2', '2020-12-18 10:42:25');


TRUNCATE manage_min_max; INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('1', '10', '500', '2', '0');


INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('2', '10', '500', '2', '0');


INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('3', '10', '500', '2', '0');


INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('4', '10', '500', '2', '0');


INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('5', '2', '5', '1', '1');


INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('6', '2', '5', '1', '12322');


INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('7', '2', '5', '1', '12330');


INSERT INTO manage_min_max (`min_max_id`, `min_level`, `max_level`, `products_id`, `inventory_ref_id`); VALUES ('8', '10', '20', '1', '12329');


TRUNCATE manage_role; INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`); VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');


INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`); VALUES ('2', '11', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');


INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`); VALUES ('3', '12', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '0', '0', '0', '1', '1', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1');


INSERT INTO manage_role (`manage_role_id`, `user_types_id`, `dashboard_view`, `manufacturer_view`, `manufacturer_create`, `manufacturer_update`, `manufacturer_delete`, `categories_view`, `categories_create`, `categories_update`, `categories_delete`, `products_view`, `products_create`, `products_update`, `products_delete`, `news_view`, `news_create`, `news_update`, `news_delete`, `customers_view`, `customers_create`, `customers_update`, `customers_delete`, `tax_location_view`, `tax_location_create`, `tax_location_update`, `tax_location_delete`, `coupons_view`, `coupons_create`, `coupons_update`, `coupons_delete`, `notifications_view`, `notifications_send`, `orders_view`, `orders_confirm`, `shipping_methods_view`, `shipping_methods_update`, `payment_methods_view`, `payment_methods_update`, `reports_view`, `website_setting_view`, `website_setting_update`, `application_setting_view`, `application_setting_update`, `general_setting_view`, `general_setting_update`, `manage_admins_view`, `manage_admins_create`, `manage_admins_update`, `manage_admins_delete`, `language_view`, `language_create`, `language_update`, `language_delete`, `profile_view`, `profile_update`, `admintype_view`, `admintype_create`, `admintype_update`, `admintype_delete`, `manage_admins_role`, `add_media`, `edit_media`, `view_media`, `delete_media`, `edit_management`, `reviews_view`, `reviews_update`); VALUES ('4', '13', '0', '1', '1', '1', '0', '1', '1', '1', '0', '1', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');


TRUNCATE manufacturers; INSERT INTO manufacturers (`manufacturers_id`, `manufacturer_name`, `manufacturers_slug`, `date_added`, `last_modified`, `manufacturer_image`, `created_at`, `updated_at`); VALUES ('1', 'Canolive', 'canolive', '', '', '130', '2020-12-17 06:44:57', '2020-12-17 09:01:25');


INSERT INTO manufacturers (`manufacturers_id`, `manufacturer_name`, `manufacturers_slug`, `date_added`, `last_modified`, `manufacturer_image`, `created_at`, `updated_at`); VALUES ('2', 'Mezan', 'mezan', '', '', '136', '2020-12-17 12:23:11', '2020-12-19 11:22:35');


INSERT INTO manufacturers (`manufacturers_id`, `manufacturer_name`, `manufacturers_slug`, `date_added`, `last_modified`, `manufacturer_image`, `created_at`, `updated_at`); VALUES ('3', 'Habib', 'habib', '', '', '137', '2020-12-17 12:25:51', '2020-12-17 12:27:07');


INSERT INTO manufacturers (`manufacturers_id`, `manufacturer_name`, `manufacturers_slug`, `date_added`, `last_modified`, `manufacturer_image`, `created_at`, `updated_at`); VALUES ('4', 'Sufi', 'sufi', '', '', '138', '2020-12-17 12:30:30', '');


INSERT INTO manufacturers (`manufacturers_id`, `manufacturer_name`, `manufacturers_slug`, `date_added`, `last_modified`, `manufacturer_image`, `created_at`, `updated_at`); VALUES ('5', 'Dalda', 'dalda', '', '', '139', '2020-12-17 12:32:45', '');


INSERT INTO manufacturers (`manufacturers_id`, `manufacturer_name`, `manufacturers_slug`, `date_added`, `last_modified`, `manufacturer_image`, `created_at`, `updated_at`); VALUES ('6', 'Unilever', 'unilever', '', '', '142', '2020-12-18 02:34:16', '');


TRUNCATE manufacturers_info; INSERT INTO manufacturers_info (`manufacturers_id`, `languages_id`, `manufacturers_url`, `url_clicked`, `date_last_click`); VALUES ('1', '1', 'http://192.168.100.53:8001/shop?category=canolive', '0', '');


INSERT INTO manufacturers_info (`manufacturers_id`, `languages_id`, `manufacturers_url`, `url_clicked`, `date_last_click`); VALUES ('2', '1', 'http://192.168.100.53:8001/shop?category=mezan', '0', '');


INSERT INTO manufacturers_info (`manufacturers_id`, `languages_id`, `manufacturers_url`, `url_clicked`, `date_last_click`); VALUES ('3', '1', 'http://192.168.100.53:8001/shop?category=habib', '0', '');


INSERT INTO manufacturers_info (`manufacturers_id`, `languages_id`, `manufacturers_url`, `url_clicked`, `date_last_click`); VALUES ('4', '1', 'http://192.168.100.53:8001/shop?category=sufi', '0', '');


INSERT INTO manufacturers_info (`manufacturers_id`, `languages_id`, `manufacturers_url`, `url_clicked`, `date_last_click`); VALUES ('5', '1', 'http://192.168.100.53:8001/shop?category=dalda', '0', '');


INSERT INTO manufacturers_info (`manufacturers_id`, `languages_id`, `manufacturers_url`, `url_clicked`, `date_last_click`); VALUES ('6', '1', 'http://192.168.100.53:8001/shop?category=unilever', '0', '');


TRUNCATE menu_translation; INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('2', '1', '1', 'Home');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('3', '1', '2', 'Homee');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('11', '2', '1', 'SHOP');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('12', '2', '2', 'SHOP');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('39', '21', '1', 'Demo');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('40', '21', '2', 'Demo');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('45', '24', '1', 'Departments');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('46', '24', '2', 'Department');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('49', '26', '1', 'Groceries');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('50', '26', '2', 'Groceries');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('51', '27', '1', 'Baking & Cooking');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('52', '27', '2', 'Baking & Cooking');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('53', '28', '1', 'Cooking Oil');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('54', '28', '2', 'Cooking Oil');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('65', '34', '1', 'Unilever');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('66', '34', '2', 'sdf');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('67', '35', '1', 'Knorr');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('68', '35', '2', 'Knorr');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('69', '36', '1', 'Dove');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('70', '36', '2', 'Dove');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('71', '37', '1', 'Brands');


INSERT INTO menu_translation (`id`, `menu_id`, `language_id`, `menu_name`); VALUES ('72', '37', '2', 'Brands');


TRUNCATE menus; INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('1', '1', '', '0', '1', '', '/', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('2', '2', '', '0', '1', '', 'shop', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('24', '3', '', '0', '1', 'departments', 'departments', '', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('26', '4', '', '24', '3', '', 'groceries', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('27', '5', '', '26', '3', '', 'baking-cooking', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('28', '6', '', '27', '3', '', 'cooking-oil', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('34', '8', '', '37', '3', '', 'unilever', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('35', '9', '', '34', '3', '', 'knorr', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('36', '10', '', '34', '3', '', 'dove', '0', '1', '', '');


INSERT INTO menus (`id`, `sort_order`, `sub_sort_order`, `parent_id`, `type`, `external_link`, `link`, `page_id`, `status`, `created_at`, `updated_at`); VALUES ('37', '7', '', '0', '1', '/brands', 'brands', '', '1', '', '');


TRUNCATE migrations; INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('1', '2019_09_24_122557_create_address_book_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('2', '2019_09_24_122557_create_alert_settings_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('3', '2019_09_24_122557_create_api_calls_list_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('4', '2019_09_24_122557_create_banners_history_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('5', '2019_09_24_122557_create_banners_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('6', '2019_09_24_122557_create_block_ips_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('7', '2019_09_24_122557_create_categories_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('8', '2019_09_24_122557_create_categories_role_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('9', '2019_09_24_122557_create_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('10', '2019_09_24_122557_create_compare_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('11', '2019_09_24_122557_create_constant_banners_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('12', '2019_09_24_122557_create_countries_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('13', '2019_09_24_122557_create_coupons_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('14', '2019_09_24_122557_create_currencies_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('15', '2019_09_24_122557_create_currency_record_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('16', '2019_09_24_122557_create_current_theme_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('17', '2019_09_24_122557_create_customers_basket_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('18', '2019_09_24_122557_create_customers_basket_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('19', '2019_09_24_122557_create_customers_info_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('20', '2019_09_24_122557_create_customers_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('21', '2019_09_24_122557_create_devices_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('22', '2019_09_24_122557_create_flash_sale_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('23', '2019_09_24_122557_create_flate_rate_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('24', '2019_09_24_122557_create_front_end_theme_content_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('25', '2019_09_24_122557_create_geo_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('26', '2019_09_24_122557_create_http_call_record_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('27', '2019_09_24_122557_create_image_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('28', '2019_09_24_122557_create_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('29', '2019_09_24_122557_create_inventory_detail_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('30', '2019_09_24_122557_create_inventory_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('31', '2019_09_24_122557_create_label_value_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('32', '2019_09_24_122557_create_labels_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('33', '2019_09_24_122557_create_languages_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('34', '2019_09_24_122557_create_liked_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('35', '2019_09_24_122557_create_manage_min_max_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('36', '2019_09_24_122557_create_manage_role_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('37', '2019_09_24_122557_create_manufacturers_info_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('38', '2019_09_24_122557_create_manufacturers_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('39', '2019_09_24_122557_create_news_categories_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('40', '2019_09_24_122557_create_news_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('41', '2019_09_24_122557_create_news_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('42', '2019_09_24_122557_create_news_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('43', '2019_09_24_122557_create_news_to_news_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('44', '2019_09_24_122557_create_orders_products_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('45', '2019_09_24_122557_create_orders_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('46', '2019_09_24_122557_create_orders_status_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('47', '2019_09_24_122557_create_orders_status_history_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('48', '2019_09_24_122557_create_orders_status_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('49', '2019_09_24_122557_create_orders_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('50', '2019_09_24_122557_create_orders_total_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('51', '2019_09_24_122557_create_pages_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('52', '2019_09_24_122557_create_pages_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('53', '2019_09_24_122557_create_payment_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('54', '2019_09_24_122557_create_payment_methods_detail_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('55', '2019_09_24_122557_create_payment_methods_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('56', '2019_09_24_122557_create_permissions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('57', '2019_09_24_122557_create_products_attributes_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('58', '2019_09_24_122557_create_products_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('59', '2019_09_24_122557_create_products_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('60', '2019_09_24_122557_create_products_options_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('61', '2019_09_24_122557_create_products_options_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('62', '2019_09_24_122557_create_products_options_values_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('63', '2019_09_24_122557_create_products_options_values_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('64', '2019_09_24_122557_create_products_shipping_rates_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('65', '2019_09_24_122557_create_products_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('66', '2019_09_24_122557_create_products_to_categories_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('67', '2019_09_24_122557_create_reviews_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('68', '2019_09_24_122557_create_reviews_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('69', '2019_09_24_122557_create_sessions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('70', '2019_09_24_122557_create_settings_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('71', '2019_09_24_122557_create_shipping_description_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('72', '2019_09_24_122557_create_shipping_methods_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('73', '2019_09_24_122557_create_sliders_images_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('74', '2019_09_24_122557_create_specials_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('75', '2019_09_24_122557_create_tax_class_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('76', '2019_09_24_122557_create_tax_rates_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('77', '2019_09_24_122557_create_units_descriptions_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('78', '2019_09_24_122557_create_units_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('79', '2019_09_24_122557_create_ups_shipping_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('80', '2019_09_24_122557_create_user_to_address_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('81', '2019_09_24_122557_create_user_types_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('82', '2019_09_24_122557_create_users_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('83', '2019_09_24_122557_create_whos_online_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('84', '2019_09_24_122557_create_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('85', '2019_09_24_122557_create_zones_to_geo_zones_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('86', '2019_12_11_070737_create_menus_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('87', '2019_12_11_070821_create_menu_translation_table', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('88', '2020_02_04_121358_top_offers', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('89', '2020_03_25_141022_create_home_banners', '1');


INSERT INTO migrations (`id`, `migration`, `batch`); VALUES ('90', '2020_07_12_000000_create_otps_table', '2');


TRUNCATE news; TRUNCATE news_categories; TRUNCATE news_categories_description; TRUNCATE news_description; TRUNCATE news_to_news_categories; TRUNCATE orders; INSERT INTO orders (`orders_id`, `total_tax`, `customers_id`, `customers_name`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `email`, `customers_address_format_id`, `delivery_name`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_address_format_id`, `billing_name`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `last_modified`, `date_purchased`, `orders_date_finished`, `currency`, `currency_value`, `order_price`, `shipping_cost`, `shipping_method`, `shipping_duration`, `order_information`, `is_seen`, `coupon_code`, `coupon_amount`, `exclude_product_ids`, `product_categories`, `excluded_product_categories`, `free_shipping`, `product_ids`, `ordered_source`, `delivery_phone`, `billing_phone`, `transaction_id`, `created_at`, `updated_at`); VALUES ('1', '0.00', '2', 'Shahzad Ali', '', 'Karachi', '', 'Karachi', '75000', 'other', 'Norway', '', 'shahzad.junejo@gmail.com', '', 'Shahzad Ali', '', 'Karachi', '', 'Karachi', '75000', 'other', 'Norway', '', 'Shahzad Ali', '', 'Karachi', '', 'Karachi', '75000', 'other', 'Norway', '0', 'Cash on Delivery', '', '', '', '', '2020-12-18 10:29:01', '2020-12-18 10:29:01', '', '$', '', '640.00', '0.00', 'flateRate', '', '[]', '1', '', '0', '', '', '', '0', '', '1', '03052589407', '03052589407', '', '', '');


INSERT INTO orders (`orders_id`, `total_tax`, `customers_id`, `customers_name`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `email`, `customers_address_format_id`, `delivery_name`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_address_format_id`, `billing_name`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `last_modified`, `date_purchased`, `orders_date_finished`, `currency`, `currency_value`, `order_price`, `shipping_cost`, `shipping_method`, `shipping_duration`, `order_information`, `is_seen`, `coupon_code`, `coupon_amount`, `exclude_product_ids`, `product_categories`, `excluded_product_categories`, `free_shipping`, `product_ids`, `ordered_source`, `delivery_phone`, `billing_phone`, `transaction_id`, `created_at`, `updated_at`); VALUES ('2', '0.00', '2', 'مرحبا سعد كيف حالك Ali', '', 'Karachi', '', 'مرحبا سعد كيف حالك', '75000', 'other', 'Pakistan', '', 'shahzad.junejo@gmail.com', '', 'مرحبا سعد كيف حالك Ali', '', 'Karachi', '', 'مرحبا سعد كيف حالك', '75000', 'other', 'Pakistan', '', 'مرحبا سعد كيف حالك Ali', '', 'Karachi', '', 'مرحبا سعد كيف حالك', '75000', 'other', 'Pakistan', '0', 'Cash on Delivery', '', '', '', '', '2020-12-18 10:38:59', '2020-12-18 10:38:59', '', '$', '', '419.00', '99.00', 'flateRate', '', '[]', '1', '', '0', '', '', '', '0', '', '1', '03052589407', '03052589407', '', '', '');


INSERT INTO orders (`orders_id`, `total_tax`, `customers_id`, `customers_name`, `customers_company`, `customers_street_address`, `customers_suburb`, `customers_city`, `customers_postcode`, `customers_state`, `customers_country`, `customers_telephone`, `email`, `customers_address_format_id`, `delivery_name`, `delivery_company`, `delivery_street_address`, `delivery_suburb`, `delivery_city`, `delivery_postcode`, `delivery_state`, `delivery_country`, `delivery_address_format_id`, `billing_name`, `billing_company`, `billing_street_address`, `billing_suburb`, `billing_city`, `billing_postcode`, `billing_state`, `billing_country`, `billing_address_format_id`, `payment_method`, `cc_type`, `cc_owner`, `cc_number`, `cc_expires`, `last_modified`, `date_purchased`, `orders_date_finished`, `currency`, `currency_value`, `order_price`, `shipping_cost`, `shipping_method`, `shipping_duration`, `order_information`, `is_seen`, `coupon_code`, `coupon_amount`, `exclude_product_ids`, `product_categories`, `excluded_product_categories`, `free_shipping`, `product_ids`, `ordered_source`, `delivery_phone`, `billing_phone`, `transaction_id`, `created_at`, `updated_at`); VALUES ('3', '0.00', '2', 'Shahzad Ali', '', 'Karachi', '', 'Karachi', '75000', 'other', 'Pakistan', '', 'shahzad.junejo@gmail.com', '', 'Shahzad Ali', '', 'Karachi', '', 'Karachi', '75000', 'other', 'Pakistan', '', 'Shahzad Ali', '', 'Karachi', '', 'Karachi', '75000', 'other', 'Pakistan', '0', 'Cash on Delivery', '', '', '', '', '2020-12-21 12:32:16', '2020-12-21 12:32:16', '', '$', '', '160.00', '0.00', 'localPickup', '', '[]', '0', '', '0', '', '', '', '0', '', '1', '03052589407', '03052589407', '', '', '');


TRUNCATE orders_products; INSERT INTO orders_products (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `final_price`, `products_tax`, `products_quantity`); VALUES ('1', '1', '1', '', 'Canolive Premium Canola And Sunflower Oil 1 Litres Bottle', '320.00', '640.00', '1', '2');


INSERT INTO orders_products (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `final_price`, `products_tax`, `products_quantity`); VALUES ('2', '2', '1', '', 'Canolive Premium Canola And Sunflower Oil 1 Litres Bottle', '320.00', '320.00', '1', '1');


INSERT INTO orders_products (`orders_products_id`, `orders_id`, `products_id`, `products_model`, `products_name`, `products_price`, `final_price`, `products_tax`, `products_quantity`); VALUES ('3', '3', '2', '', 'Mezan Cooking Oil', '259.00', '160.00', '1', '1');


TRUNCATE orders_products_attributes; INSERT INTO orders_products_attributes (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`); VALUES ('1', '1', '1', '1', 'Capacity', '1 ltr', '0.00', '+');


INSERT INTO orders_products_attributes (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`); VALUES ('2', '2', '2', '1', 'Capacity', '1 ltr', '0.00', '+');


INSERT INTO orders_products_attributes (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`); VALUES ('3', '3', '3', '2', 'Capacity', '1 ltr', '0.00', '+');


INSERT INTO orders_products_attributes (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`); VALUES ('4', '3', '3', '2', 'Type', 'Sunflower Oil', '0.00', '+');


INSERT INTO orders_products_attributes (`orders_products_attributes_id`, `orders_id`, `orders_products_id`, `products_id`, `products_options`, `products_options_values`, `options_values_price`, `price_prefix`); VALUES ('5', '3', '3', '2', 'Color', 'Green', '10.00', '+');


TRUNCATE orders_status; INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('1', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('2', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('3', '0', '0', '2');


INSERT INTO orders_status (`orders_status_id`, `public_flag`, `downloads_flag`, `role_id`); VALUES ('4', '0', '0', '2');


TRUNCATE orders_status_description; INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('1', '1', 'Pending', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('2', '2', 'Completed', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('3', '3', 'Cancel', '1');


INSERT INTO orders_status_description (`orders_status_description_id`, `orders_status_id`, `orders_status_name`, `language_id`); VALUES ('4', '4', 'Return', '1');


TRUNCATE orders_status_history; INSERT INTO orders_status_history (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`); VALUES ('1', '1', '1', '2020-12-18 10:29:01', '1', '');


INSERT INTO orders_status_history (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`); VALUES ('2', '1', '2', '2020-12-18 10:30:18', '1', '');


INSERT INTO orders_status_history (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`); VALUES ('3', '2', '1', '2020-12-18 10:38:59', '1', '');


INSERT INTO orders_status_history (`orders_status_history_id`, `orders_id`, `orders_status_id`, `date_added`, `customer_notified`, `comments`); VALUES ('4', '3', '1', '2020-12-21 12:32:16', '1', '');


TRUNCATE orders_total; TRUNCATE otps; TRUNCATE pages; TRUNCATE pages_description; TRUNCATE payment_description; INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('1', '1', 'Cash on Delivery', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('4', '2', 'Stripe', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('5', '3', 'Paypal', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('6', '4', 'Braintree', '1', 'Credit Card', 'Paypal');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('7', '5', 'Instamojo', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('8', '0', 'Cybersoure', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('9', '6', 'Hyperpay', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('10', '7', 'Razor Pay', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('11', '8', 'PayTm', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('12', '9', 'Direct Bank Transfer', '1', 'Make your payment directly into our bank account. Please use your Order ID as the payment reference.', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('13', '10', 'Paystack', '1', '', '');


INSERT INTO payment_description (`id`, `payment_methods_id`, `name`, `language_id`, `sub_name_1`, `sub_name_2`); VALUES ('14', '11', 'Midtrans', '1', '', '');


TRUNCATE payment_methods; INSERT INTO payment_methods (`payment_methods_id`, `payment_method`, `status`, `environment`, `created_at`, `updated_at`); VALUES ('4', 'cash_on_delivery', '1', '0', '2019-09-18 16:56:37', '0000-00-00 00:00:00');


TRUNCATE payment_methods_detail; INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('3', '1', 'merchant_id', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('4', '1', 'public_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('5', '1', 'private_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('9', '2', 'secret_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('10', '2', 'publishable_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('15', '3', 'id', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('18', '3', 'payment_currency', 'USD');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('21', '5', 'api_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('22', '5', 'auth_token', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('23', '5', 'client_id', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('24', '5', 'client_secret', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('32', '6', 'userid', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('33', '6', 'password', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('34', '6', 'entityid', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('35', '7', 'RAZORPAY_KEY', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('36', '7', 'RAZORPAY_SECRET', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('37', '8', 'paytm_mid', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('39', '8', 'paytm_key', 'w#');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('40', '8', 'current_domain_name', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('41', '9', 'account_name', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('42', '9', 'account_number', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('43', '9', 'bank_name', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('44', '9', 'short_code', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('45', '9', 'iban', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('46', '9', 'swift', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('47', '10', 'secret_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('48', '10', 'public_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('49', '11', 'merchant_id', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('50', '11', 'server_key', '');


INSERT INTO payment_methods_detail (`id`, `payment_methods_id`, `key`, `value`); VALUES ('51', '11', 'client_key', '');


TRUNCATE permissions; TRUNCATE products; INSERT INTO products (`products_id`, `products_quantity`, `products_model`, `products_image`, `products_video_link`, `products_price`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_weight_unit`, `products_status`, `is_current`, `products_tax_class_id`, `manufacturers_id`, `products_ordered`, `products_liked`, `low_limit`, `is_feature`, `products_slug`, `products_type`, `products_min_order`, `products_max_stock`, `created_at`, `updated_at`); VALUES ('2', '0', '', '151', '', '100.00', '0000-00-00 00:00:00', '', '', '300', 'GM', '1', '1', '0', '6', '0', '0', '0', '1', 'knorr-tomato-ketchup', '1', '1', '1', '2020-12-17 12:50:55', '2020-12-21 02:36:58');


TRUNCATE products_attributes; INSERT INTO products_attributes (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `is_default`); VALUES ('11', '2', '6', '10', '0.00', '+', '0');


INSERT INTO products_attributes (`products_attributes_id`, `products_id`, `options_id`, `options_values_id`, `options_values_price`, `price_prefix`, `is_default`); VALUES ('12', '2', '6', '11', '128.00', '+', '0');


TRUNCATE products_description; INSERT INTO products_description (`id`, `products_id`, `language_id`, `products_name`, `products_description`, `products_url`, `products_viewed`, `products_left_banner`, `products_left_banner_start_date`, `products_left_banner_expire_date`, `products_right_banner`, `products_right_banner_start_date`, `products_right_banner_expire_date`); VALUES ('3', '2', '1', 'KNORR TOMATO KETCHUP', '<p>Knorr Professional Tomato Ketchup is made with 100% real and natural tomatoes, without artificial colors and flavors for serving with snacks, sandwiches, and usage in cooking applications.</p>', '', '0', '', '0', '0', '', '0', '0');


TRUNCATE products_images; INSERT INTO products_images (`id`, `products_id`, `image`, `htmlcontent`, `sort_order`); VALUES ('1', '1', '135', '3 ltr', '1');


INSERT INTO products_images (`id`, `products_id`, `image`, `htmlcontent`, `sort_order`); VALUES ('4', '2', '151', '', '1');


TRUNCATE products_options; INSERT INTO products_options (`products_options_id`, `products_options_name`); VALUES ('5', 'ML');


INSERT INTO products_options (`products_options_id`, `products_options_name`); VALUES ('6', 'GM');


TRUNCATE products_options_descriptions; INSERT INTO products_options_descriptions (`products_options_descriptions_id`, `language_id`, `options_name`, `products_options_id`); VALUES ('9', '1', 'ML', '5');


INSERT INTO products_options_descriptions (`products_options_descriptions_id`, `language_id`, `options_name`, `products_options_id`); VALUES ('10', '1', 'GM', '6');


TRUNCATE products_options_values; INSERT INTO products_options_values (`products_options_values_id`, `products_options_id`, `products_options_values_name`); VALUES ('10', '6', '300');


INSERT INTO products_options_values (`products_options_values_id`, `products_options_id`, `products_options_values_name`); VALUES ('11', '6', '800');


TRUNCATE products_options_values_descriptions; INSERT INTO products_options_values_descriptions (`products_options_values_descriptions_id`, `language_id`, `options_values_name`, `products_options_values_id`); VALUES ('19', '1', '300', '10');


INSERT INTO products_options_values_descriptions (`products_options_values_descriptions_id`, `language_id`, `options_values_name`, `products_options_values_id`); VALUES ('20', '1', '800', '11');


TRUNCATE products_shipping_rates; INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('1', '0', '10', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('2', '10', '20', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('3', '20', '30', '10', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('4', '30', '50', '50', '1', '1');


INSERT INTO products_shipping_rates (`products_shipping_rates_id`, `weight_from`, `weight_to`, `weight_price`, `unit_id`, `products_shipping_status`); VALUES ('5', '50', '100000', '70', '1', '1');


TRUNCATE products_to_categories; INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('58', '2', '4');


INSERT INTO products_to_categories (`products_to_categories_id`, `products_id`, `categories_id`); VALUES ('59', '2', '5');


TRUNCATE reviews; INSERT INTO reviews (`reviews_id`, `products_id`, `customers_id`, `customers_name`, `reviews_rating`, `reviews_status`, `reviews_read`, `vendors_id`, `created_at`, `updated_at`); VALUES ('1', '1', '2', 'Shahzad', '5', '1', '1', '', '2020-12-18 10:43:58', '');


TRUNCATE reviews_description; INSERT INTO reviews_description (`id`, `review_id`, `language_id`, `reviews_text`); VALUES ('1', '1', '1', 'Great Experience, I will buy again');


TRUNCATE sessions; TRUNCATE settings; INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('1', 'facebook_app_id', 'FB_CLIENT_ID', '2018-04-27 00:00:00', '2020-12-21 01:34:03');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('2', 'facebook_secret_id', 'FB_SECRET_KEY', '2018-04-27 00:00:00', '2020-12-21 01:34:03');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('3', 'facebook_login', '1', '2018-04-27 00:00:00', '2020-12-21 01:34:03');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('4', 'contact_us_email', '', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('5', 'address', 'Shahrah-e-Usman, Sector 5c/4 Sector 5 C 4 North Karachi Twp', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('6', 'city', 'Karachi', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('7', 'state', 'Sindh', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('8', 'zip', '75850', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('9', 'country', 'Pakistan', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('10', 'latitude', '24.989342', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('11', 'longitude', '67.065109', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('12', 'phone_no', '+92 3122887239', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('13', 'fcm_android', '', '2018-04-27 00:00:00', '2019-02-05 11:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('14', 'fcm_ios', '', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('15', 'fcm_desktop', '', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('16', 'website_logo', 'images/media/2020/12/G79LA17209.png', '2018-04-27 00:00:00', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('17', 'fcm_android_sender_id', '', '2018-04-27 00:00:00', '2020-12-21 12:22:23');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('18', 'fcm_ios_sender_id', '', '2018-04-27 00:00:00', '2019-02-05 11:42:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('19', 'app_name', 'Al Syed Store', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('20', 'currency_symbol', '$', '2018-04-27 00:00:00', '2018-11-19 07:26:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('21', 'new_product_duration', '20', '2018-04-27 00:00:00', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('22', 'notification_title', 'Ionic Ecommerce', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('23', 'notification_text', 'A bundle of products waiting for you!', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('24', 'lazzy_loading_effect', 'Detail', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('25', 'footer_button', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('26', 'cart_button', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('27', 'featured_category', '', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('28', 'notification_duration', 'year', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('29', 'home_style', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('30', 'wish_list_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('31', 'edit_profile_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('32', 'shipping_address_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('33', 'my_orders_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('34', 'contact_us_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('35', 'about_us_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('36', 'news_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('37', 'intro_page', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('38', 'setting_page', '1', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('39', 'share_app', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('40', 'rate_app', '1', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('41', 'site_url', 'URL', '2018-04-27 00:00:00', '2018-11-19 07:26:01');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('42', 'admob', '0', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('43', 'admob_id', 'ID', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('44', 'ad_unit_id_banner', 'Unit ID', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('45', 'ad_unit_id_interstitial', 'Indestrial', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('46', 'category_style', '4', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('47', 'package_name', 'package name', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('48', 'google_analytic_id', 'test', '2018-04-27 00:00:00', '2019-05-15 10:58:30');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('49', 'themes', 'themeone', '2018-04-27 00:00:00', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('50', 'company_name', '#', '2018-04-27 00:00:00', '2019-10-07 09:52:24');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('51', 'facebook_url', '#', '2018-04-27 00:00:00', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('52', 'google_url', '#', '2018-04-27 00:00:00', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('53', 'twitter_url', '#', '2018-04-27 00:00:00', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('54', 'linked_in', '#', '2018-04-27 00:00:00', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('55', 'default_notification', 'onesignal', '2018-04-27 00:00:00', '2020-12-21 12:22:23');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('56', 'onesignal_app_id', '02fd4fb4-bd20-4ee4-8a97-68bd8bbf7350', '2018-04-27 00:00:00', '2020-12-21 12:22:23');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('57', 'onesignal_sender_id', '02fd4fb4-bd20-4ee4-8a97-68bd8bbf7350', '2018-04-27 00:00:00', '2020-12-21 12:22:23');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('58', 'ios_admob', '0', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('59', 'ios_admob_id', 'AdMob ID', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('60', 'ios_ad_unit_id_banner', 'Unit ID Banner', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('61', 'ios_ad_unit_id_interstitial', 'ID Interstitial', '2018-04-27 00:00:00', '2019-05-15 10:58:05');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('62', 'google_login', '0', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('63', 'google_app_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('64', 'google_secret_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('65', 'google_callback_url', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('66', 'facebook_callback_url', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('67', 'is_app_purchased', '1', '', '2018-05-04 03:24:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('68', 'is_web_purchased', '1', '', '2018-05-04 03:24:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('69', 'consumer_key', 'dadb7a7c1557917902724bbbf5', '', '2019-05-15 10:58:22');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('70', 'consumer_secret', '3ba77f821557917902b1d57373', '', '2019-05-15 10:58:22');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('71', 'order_email', 'orders@alsyedstore.com', '', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('72', 'website_themes', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('73', 'seo_title', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('74', 'seo_metatag', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('75', 'seo_keyword', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('76', 'seo_description', '', '', '2018-11-19 07:21:57');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('77', 'before_head_tag', '', '', '2018-11-19 07:22:15');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('78', 'end_body_tag', 'name', '', '2019-10-11 11:57:29');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('79', 'sitename_logo', 'logo', '', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('80', 'website_name', '<strong>E</strong>COMMERCE', '', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('81', 'web_home_pages_style', 'two', '', '2018-11-19 07:22:25');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('82', 'web_color_style', 'app.theme.7', '', '2020-12-18 10:02:14');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('83', 'free_shipping_limit', '0', '', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('84', 'app_icon_image', 'icon', '', '2019-02-05 10:12:59');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('85', 'twilio_status', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('86', 'twilio_authy_api_id', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('87', 'favicon', 'images/admin_logo/logo-laravel-blue-v1.png', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('88', 'Thumbnail_height', '150', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('89', 'Thumbnail_width', '150', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('90', 'Medium_height', '400', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('91', 'Medium_width', '400', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('92', 'Large_height', '900', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('93', 'Large_width', '900', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('94', 'environmentt', 'local', '', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('95', 'maintenance_text', 'Website is under maintenance', '', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('96', 'package_charge_taxt', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('97', 'order_commission', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('98', 'all_items_price_included_tax', 'yes', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('99', 'all_items_price_included_tax_value', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('100', 'driver_accept_multiple_order', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('101', 'min_order_price', '', '', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('102', 'youtube_link', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('103', 'external_website_link', 'alsyedstore.com', '', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('104', 'google_map_api', '', '', '2020-12-21 01:27:44');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('105', 'is_pos_purchased', '1', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('106', 'admin_version', '1.0.19', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('107', 'app_version', '1.0.19', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('108', 'web_version', '1.0.19', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('109', 'pos_version', '0', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('110', 'android_app_link', '#', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('111', 'iphone_app_link', '#', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('112', 'about_content', 'Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum', '', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('113', 'contact_content', 'Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum Lorum Ipsum Upsum Kupsum Jipsum Mipsum', '', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('114', 'contents', '', '', '');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('115', 'fb_redirect_url', 'http://YOUR_DOMAIN_NAME/login/facebook/callback', '', '2020-12-21 01:34:03');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('116', 'google_client_id', 'GOOGLE_CLIENT_ID', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('117', 'google_client_secret', 'GOOGLE_SECRET_KEY', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('118', 'google_redirect_url', 'http://YOUR_DOMAIN_NAME/login/google/callback', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('119', 'newsletter', '0', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('120', 'allow_cookies', '0', '', '2020-12-17 09:49:54');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('121', 'card_style', '1', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('122', 'banner_style', '1', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('123', 'mail_chimp_api', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('124', 'mail_chimp_list_id', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('125', 'newsletter_image', 'images/media/2019/10/newsletter.jpg', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('126', 'instauserid', '', '', '2019-11-01 06:58:36');


INSERT INTO settings (`id`, `name`, `value`, `created_at`, `updated_at`); VALUES ('127', 'web_card_style', '11', '', '2020-12-21 02:09:13');


TRUNCATE shipping_description; INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('4', 'Local Pickup', '1', 'local_pickup', '');


INSERT INTO shipping_description (`id`, `name`, `language_id`, `table_name`, `sub_labels`); VALUES ('7', 'Shipping Fee', '1', 'flate_rate', '');


TRUNCATE shipping_methods; INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('3', 'localPickup', '0', '1', 'local_pickup');


INSERT INTO shipping_methods (`shipping_methods_id`, `methods_type_link`, `isDefault`, `status`, `table_name`); VALUES ('4', 'flateRate', '1', '1', 'flate_rate');


TRUNCATE sliders_images; INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('1', 'Left Slider with Thumbs (770x400)', '', '5', '109', '', '', '2035-11-15 00:00:00', '2020-04-13 14:36:18', '1', 'topseller', '2020-04-13 14:36:18', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('4', 'Full Screen Slider (1600x420)', '', '1', '111', '', '', '2020-07-15 00:00:00', '2020-04-13 14:32:27', '1', 'special', '2020-04-13 14:32:27', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('7', 'Full Page Slider (1170x420)', '', '2', '108', '', '', '2025-11-26 00:00:00', '2020-04-13 14:31:54', '1', 'topseller', '2020-04-13 14:31:54', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('10', 'Right Slider with Thumbs (770x400)', '', '3', '110', '', '', '2025-10-20 00:00:00', '2020-04-13 14:33:23', '1', 'topseller', '2020-04-13 14:33:23', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('13', 'Right Slider with Navigation (770x400)', '', '4', '109', '', '', '2025-07-24 00:00:00', '2020-04-13 14:33:58', '1', 'topseller', '2020-04-13 14:33:58', '1');


INSERT INTO sliders_images (`sliders_id`, `sliders_title`, `sliders_url`, `carousel_id`, `sliders_image`, `sliders_group`, `sliders_html_text`, `expires_date`, `date_added`, `status`, `type`, `date_status_change`, `languages_id`); VALUES ('29', 'Right Slider with Thumbs (770x400)', '', '3', '145', '', '', '2020-12-25 00:00:00', '2020-12-18 11:24:31', '1', 'topseller', '', '1');


TRUNCATE specials; INSERT INTO specials (`specials_id`, `products_id`, `specials_new_products_price`, `specials_date_added`, `specials_last_modified`, `expires_date`, `date_status_change`, `status`); VALUES ('1', '2', '150.00', '1608541950', '2020', '1609286400', '2020', '0');


INSERT INTO specials (`specials_id`, `products_id`, `specials_new_products_price`, `specials_date_added`, `specials_last_modified`, `expires_date`, `date_status_change`, `status`); VALUES ('2', '2', '150.00', '1608560672', '2020', '1609286400', '2020', '0');


INSERT INTO specials (`specials_id`, `products_id`, `specials_new_products_price`, `specials_date_added`, `specials_last_modified`, `expires_date`, `date_status_change`, `status`); VALUES ('3', '2', '90.00', '1608560741', '2020', '1609286400', '2020', '0');


INSERT INTO specials (`specials_id`, `products_id`, `specials_new_products_price`, `specials_date_added`, `specials_last_modified`, `expires_date`, `date_status_change`, `status`); VALUES ('4', '2', '90.00', '1608560931', '2020', '1609286400', '2020', '0');


INSERT INTO specials (`specials_id`, `products_id`, `specials_new_products_price`, `specials_date_added`, `specials_last_modified`, `expires_date`, `date_status_change`, `status`); VALUES ('5', '2', '90.00', '1608561419', '0', '1609286400', '0', '1');


TRUNCATE tax_class; TRUNCATE tax_rates; TRUNCATE top_offers; INSERT INTO top_offers (`top_offers_id`, `top_offers_text`, `language_id`, `created_at`, `updated_at`); VALUES ('1', '<div class=\\\"pro-info\\\">
                Get<strong> UPTO 40% OFF </strong>on your 1st order
                <div class=\\\"pro-link-dropdown js-toppanel-link-dropdown\\\">
                  <a href=\\\"shop?type=speciall\\\" class=\\\"pro-dropdown-toggle\\\">
                    More details
                  </a>
                  
                </div>
            </div>', '1', '2020-02-04 05:14:16', '2020-12-21 01:52:50');


INSERT INTO top_offers (`top_offers_id`, `top_offers_text`, `language_id`, `created_at`, `updated_at`); VALUES ('2', '<div class=\\\"pro-info\\\">
                Get<strong> UPTO 40% OFF </strong>on your 1st order
                <div class=\\\"pro-link-dropdown js-toppanel-link-dropdown\\\">
                  <a href=\\\"shop?type=speciall\\\" class=\\\"pro-dropdown-toggle\\\">
                    More details
                  </a>
                  
                </div>
            </div>', '1', '2020-02-04 05:14:16', '2020-12-21 01:52:50');


TRUNCATE units; INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('2', '1', '', '', '', '');


INSERT INTO units (`unit_id`, `is_active`, `date_added`, `last_modified`, `created_at`, `updated_at`); VALUES ('3', '1', '', '', '', '');


TRUNCATE units_descriptions; INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('3', 'GM', '1', '2', '', '');


INSERT INTO units_descriptions (`units_description_id`, `units_name`, `languages_id`, `unit_id`, `created_at`, `updated_at`); VALUES ('4', 'ML', '1', '3', '', '');


TRUNCATE ups_shipping; INSERT INTO ups_shipping (`ups_id`, `pickup_method`, `isDisplayCal`, `serviceType`, `shippingEnvironment`, `user_name`, `access_key`, `password`, `person_name`, `company_name`, `phone_number`, `address_line_1`, `address_line_2`, `country`, `state`, `post_code`, `city`, `no_of_package`, `parcel_height`, `parcel_width`, `title`); VALUES ('1', '07', '', 'US_01,US_02,US_03,US_12,US_13,US_14,US_59', '0', 'nyblueprint', 'FCD7C8F94CB5EF46', 'delfia11', '', '', '', 'D Ground', '', 'US', 'NY', '10312', 'New York City', '', '', '', '');


TRUNCATE user_to_address; INSERT INTO user_to_address (`id`, `user_id`, `address_book_id`, `is_default`); VALUES ('1', '1', '1', '1');


TRUNCATE user_types; INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('1', 'Super Admin', '1534774230', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('2', 'Customers', '1534777027', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('3', 'Vendors', '1538390209', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('4', 'Delivery Guy', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('5', 'Test 1', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('6', 'Test 2', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('7', 'Test 3', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('8', 'Test 4', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('9', 'Test 5', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('10', 'Test 6', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('11', 'Admin', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('12', 'Manager', '1542965906', '', '1');


INSERT INTO user_types (`user_types_id`, `user_types_name`, `created_at`, `updated_at`, `isActive`); VALUES ('13', 'Data Entry', '1542965906', '', '1');


TRUNCATE users; INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('1', '1', '', 'Shahzad', 'Ali', '', '0', '', '+923122887239', 'admin@alsyedstore.com', '$2y$10$Yk.cdl78HkwO5Uk6nOVA/uVDiJvmPt1iMPfcm2NAK2waFxUcMDRSa', '', '1', '0', '', '', '', '', '2020-12-14 11:14:24', '2020-12-21 01:36:28');


INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('2', '2', '', 'Shahzad', 'Ali', '1', '0', '', '03052589407', 'shahzad.junejo@gmail.com', '$2y$10$x8wKSP0ZFJZemCGAt99ZzeReJcw7S71PmV3gqUScNn3hVH5qoDp2a', '', '1', '0', '', '', '', '28/02/1991', '2020-12-18 10:23:27', '');


INSERT INTO users (`id`, `role_id`, `user_name`, `first_name`, `last_name`, `gender`, `default_address_id`, `country_code`, `phone`, `email`, `password`, `avatar`, `status`, `is_seen`, `phone_verified`, `remember_token`, `auth_id_tiwilo`, `dob`, `created_at`, `updated_at`); VALUES ('3', '2', '', 'Testing', 'User', '0', '0', '', '03212241655', 'phoenix.saad94@gmail.com', '$2y$10$HWS9FRMX5DNW41gETd5HaeFzJ5dPirXwhYY3/tbHQ9J3hIAngVrEK', '', '1', '0', '', '', '', '16/07/1994', '2020-12-21 12:50:00', '2020-12-21 12:50:00');


TRUNCATE whos_online; TRUNCATE zones; INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('1', '223', 'AL', 'Alabama');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('2', '223', 'AK', 'Alaska');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('3', '223', 'AS', 'American Samoa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('4', '223', 'AZ', 'Arizona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('5', '223', 'AR', 'Arkansas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('6', '223', 'AF', 'Armed Forces Africa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('7', '223', 'AA', 'Armed Forces Americas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('8', '223', 'AC', 'Armed Forces Canada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('9', '223', 'AE', 'Armed Forces Europe');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('10', '223', 'AM', 'Armed Forces Middle East');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('11', '223', 'AP', 'Armed Forces Pacific');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('12', '223', 'CA', 'California');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('13', '223', 'CO', 'Colorado');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('14', '223', 'CT', 'Connecticut');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('15', '223', 'DE', 'Delaware');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('16', '223', 'DC', 'District of Columbia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('17', '223', 'FM', 'Federated States Of Micronesia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('18', '223', 'FL', 'Florida');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('19', '223', 'GA', 'Georgia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('20', '223', 'GU', 'Guam');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('21', '223', 'HI', 'Hawaii');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('22', '223', 'ID', 'Idaho');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('23', '223', 'IL', 'Illinois');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('24', '223', 'IN', 'Indiana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('25', '223', 'IA', 'Iowa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('26', '223', 'KS', 'Kansas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('27', '223', 'KY', 'Kentucky');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('28', '223', 'LA', 'Louisiana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('29', '223', 'ME', 'Maine');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('30', '223', 'MH', 'Marshall Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('31', '223', 'MD', 'Maryland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('32', '223', 'MA', 'Massachusetts');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('33', '223', 'MI', 'Michigan');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('34', '223', 'MN', 'Minnesota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('35', '223', 'MS', 'Mississippi');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('36', '223', 'MO', 'Missouri');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('37', '223', 'MT', 'Montana');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('38', '223', 'NE', 'Nebraska');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('39', '223', 'NV', 'Nevada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('40', '223', 'NH', 'New Hampshire');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('41', '223', 'NJ', 'New Jersey');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('42', '223', 'NM', 'New Mexico');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('43', '223', 'NY', 'New York');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('44', '223', 'NC', 'North Carolina');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('45', '223', 'ND', 'North Dakota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('46', '223', 'MP', 'Northern Mariana Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('47', '223', 'OH', 'Ohio');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('48', '223', 'OK', 'Oklahoma');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('49', '223', 'OR', 'Oregon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('50', '223', 'PW', 'Palau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('51', '223', 'PA', 'Pennsylvania');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('52', '223', 'PR', 'Puerto Rico');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('53', '223', 'RI', 'Rhode Island');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('54', '223', 'SC', 'South Carolina');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('55', '223', 'SD', 'South Dakota');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('56', '223', 'TN', 'Tennessee');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('57', '223', 'TX', 'Texas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('58', '223', 'UT', 'Utah');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('59', '223', 'VT', 'Vermont');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('60', '223', 'VI', 'Virgin Islands');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('61', '223', 'VA', 'Virginia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('62', '223', 'WA', 'Washington');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('63', '223', 'WV', 'West Virginia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('64', '223', 'WI', 'Wisconsin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('65', '223', 'WY', 'Wyoming');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('66', '38', 'AB', 'Alberta');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('67', '38', 'BC', 'British Columbia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('68', '38', 'MB', 'Manitoba');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('69', '38', 'NF', 'Newfoundland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('70', '38', 'NB', 'New Brunswick');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('71', '38', 'NS', 'Nova Scotia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('72', '38', 'NT', 'Northwest Territories');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('73', '38', 'NU', 'Nunavut');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('74', '38', 'ON', 'Ontario');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('75', '38', 'PE', 'Prince Edward Island');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('76', '38', 'QC', 'Quebec');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('77', '38', 'SK', 'Saskatchewan');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('78', '38', 'YT', 'Yukon Territory');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('79', '81', 'NDS', 'Niedersachsen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('80', '81', 'BAW', 'Baden-Württemberg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('81', '81', 'BAY', 'Bayern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('82', '81', 'BER', 'Berlin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('83', '81', 'BRG', 'Brandenburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('84', '81', 'BRE', 'Bremen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('85', '81', 'HAM', 'Hamburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('86', '81', 'HES', 'Hessen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('87', '81', 'MEC', 'Mecklenburg-Vorpommern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('88', '81', 'NRW', 'Nordrhein-Westfalen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('89', '81', 'RHE', 'Rheinland-Pfalz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('90', '81', 'SAR', 'Saarland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('91', '81', 'SAS', 'Sachsen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('92', '81', 'SAC', 'Sachsen-Anhalt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('93', '81', 'SCN', 'Schleswig-Holstein');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('94', '81', 'THE', 'Thüringen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('95', '14', 'WI', 'Wien');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('96', '14', 'NO', 'Niederösterreich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('97', '14', 'OO', 'Oberösterreich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('98', '14', 'SB', 'Salzburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('99', '14', 'KN', 'Kärnten');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('100', '14', 'ST', 'Steiermark');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('101', '14', 'TI', 'Tirol');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('102', '14', 'BL', 'Burgenland');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('103', '14', 'VB', 'Voralberg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('104', '204', 'AG', 'Aargau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('105', '204', 'AI', 'Appenzell Innerrhoden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('106', '204', 'AR', 'Appenzell Ausserrhoden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('107', '204', 'BE', 'Bern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('108', '204', 'BL', 'Basel-Landschaft');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('109', '204', 'BS', 'Basel-Stadt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('110', '204', 'FR', 'Freiburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('111', '204', 'GE', 'Genf');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('112', '204', 'GL', 'Glarus');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('113', '204', 'JU', 'Graubünden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('114', '204', 'JU', 'Jura');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('115', '204', 'LU', 'Luzern');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('116', '204', 'NE', 'Neuenburg');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('117', '204', 'NW', 'Nidwalden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('118', '204', 'OW', 'Obwalden');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('119', '204', 'SG', 'St. Gallen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('120', '204', 'SH', 'Schaffhausen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('121', '204', 'SO', 'Solothurn');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('122', '204', 'SZ', 'Schwyz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('123', '204', 'TG', 'Thurgau');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('124', '204', 'TI', 'Tessin');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('125', '204', 'UR', 'Uri');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('126', '204', 'VD', 'Waadt');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('127', '204', 'VS', 'Wallis');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('128', '204', 'ZG', 'Zug');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('129', '204', 'ZH', 'Zürich');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('130', '195', 'A Coruña', 'A Coruña');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('131', '195', 'Alava', 'Alava');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('132', '195', 'Albacete', 'Albacete');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('133', '195', 'Alicante', 'Alicante');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('134', '195', 'Almeria', 'Almeria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('135', '195', 'Asturias', 'Asturias');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('136', '195', 'Avila', 'Avila');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('137', '195', 'Badajoz', 'Badajoz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('138', '195', 'Baleares', 'Baleares');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('139', '195', 'Barcelona', 'Barcelona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('140', '195', 'Burgos', 'Burgos');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('141', '195', 'Caceres', 'Caceres');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('142', '195', 'Cadiz', 'Cadiz');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('143', '195', 'Cantabria', 'Cantabria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('144', '195', 'Castellon', 'Castellon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('145', '195', 'Ceuta', 'Ceuta');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('146', '195', 'Ciudad Real', 'Ciudad Real');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('147', '195', 'Cordoba', 'Cordoba');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('148', '195', 'Cuenca', 'Cuenca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('149', '195', 'Girona', 'Girona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('150', '195', 'Granada', 'Granada');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('151', '195', 'Guadalajara', 'Guadalajara');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('152', '195', 'Guipuzcoa', 'Guipuzcoa');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('153', '195', 'Huelva', 'Huelva');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('154', '195', 'Huesca', 'Huesca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('155', '195', 'Jaen', 'Jaen');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('156', '195', 'La Rioja', 'La Rioja');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('157', '195', 'Las Palmas', 'Las Palmas');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('158', '195', 'Leon', 'Leon');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('159', '195', 'Lleida', 'Lleida');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('160', '195', 'Lugo', 'Lugo');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('161', '195', 'Madrid', 'Madrid');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('162', '195', 'Malaga', 'Malaga');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('163', '195', 'Melilla', 'Melilla');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('164', '195', 'Murcia', 'Murcia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('165', '195', 'Navarra', 'Navarra');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('166', '195', 'Ourense', 'Ourense');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('167', '195', 'Palencia', 'Palencia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('168', '195', 'Pontevedra', 'Pontevedra');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('169', '195', 'Salamanca', 'Salamanca');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('170', '195', 'Santa Cruz de Tenerife', 'Santa Cruz de Tenerife');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('171', '195', 'Segovia', 'Segovia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('172', '195', 'Sevilla', 'Sevilla');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('173', '195', 'Soria', 'Soria');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('174', '195', 'Tarragona', 'Tarragona');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('175', '195', 'Teruel', 'Teruel');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('176', '195', 'Toledo', 'Toledo');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('177', '195', 'Valencia', 'Valencia');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('178', '195', 'Valladolid', 'Valladolid');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('179', '195', 'Vizcaya', 'Vizcaya');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('180', '195', 'Zamora', 'Zamora');


INSERT INTO zones (`zone_id`, `zone_country_id`, `zone_code`, `zone_name`); VALUES ('181', '195', 'Zaragoza', 'Zaragoza');


TRUNCATE zones_to_geo_zones; 